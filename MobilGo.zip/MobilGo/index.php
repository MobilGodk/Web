<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
get_header();
?>

<div class="container mobilgo-index-content">
    <h1>Welcome to MobilGo</h1>
    <p>Your Smartphone Matters</p>
</div>

<?php
get_footer();

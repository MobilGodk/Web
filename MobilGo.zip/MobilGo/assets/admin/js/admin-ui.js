document.addEventListener("DOMContentLoaded", function () {
    const iconData =
        window.mobilgoAdminIcons && Array.isArray(window.mobilgoAdminIcons.items)
            ? window.mobilgoAdminIcons.items
            : [];

    let activeIconPicker = null;

    function renderIconPreview(item) {
        if (!item || !item.value) {
            return "<span>No icon</span>";
        }

        if (item.type === "svg") {
            return '<span class="mobilgo-icon-item-svg-label">SVG</span>';
        }

        return '<i class="' + item.value + '" aria-hidden="true"></i>';
    }

    function renderIconGrid(filterText = "") {
        const grid = document.getElementById("mobilgo-icon-grid");
        if (!grid) return;

        const search = filterText.toLowerCase().trim();
        grid.innerHTML = "";

        iconData.forEach(function (item) {
            const haystack = (
                (item.label || "") +
                " " +
                (item.value || "") +
                " " +
                (item.type || "")
            ).toLowerCase();

            if (search && !haystack.includes(search)) {
                return;
            }

            const button = document.createElement("button");
            button.type = "button";
            button.className = "mobilgo-icon-item";
            button.setAttribute("data-type", item.type || "fa");
            button.setAttribute("data-value", item.value || "");
            button.setAttribute("data-label", item.label || "");
            button.innerHTML =
                renderIconPreview(item) +
                "<span>" +
                (item.label || item.value || "Icon") +
                "</span>";

            grid.appendChild(button);
        });
    }

    function openIconModal(picker) {
        const modal = document.getElementById("mobilgo-icon-modal");
        const search = document.getElementById("mobilgo-icon-search");

        if (!modal) return;

        activeIconPicker = picker;
        modal.style.display = "block";
        renderIconGrid("");

        if (search) {
            search.value = "";
            setTimeout(function () {
                search.focus();
            }, 50);
        }
    }

    function closeIconModal() {
        const modal = document.getElementById("mobilgo-icon-modal");
        if (modal) {
            modal.style.display = "none";
        }
        activeIconPicker = null;
    }

    function updatePickerPreview(picker, type, value) {
        if (!picker) return;

        const input = picker.querySelector(".mobilgo-icon-input");
        const typeInput = picker.querySelector(".mobilgo-icon-type-input");
        const preview = picker.querySelector(".mobilgo-icon-preview");
        const code = picker.querySelector(".mobilgo-icon-class-text code");

        if (input) {
            input.value = value || "";
        }

        if (typeInput) {
            typeInput.value = type || "fa";
        }

        if (preview) {
            if (!value) {
                preview.innerHTML = "<span>No icon</span>";
            } else if (type === "svg") {
                preview.innerHTML = '<span class="mobilgo-icon-item-svg-label">SVG</span>';
            } else {
                preview.innerHTML = '<i class="' + value + '" aria-hidden="true"></i>';
            }
        }

        if (code) {
            code.textContent = value ? type + ":" + value : "";
        }
    }

    function toggleSwitchButton(button) {
        const group = button.closest(".mobilgo-switch-group");
        if (!group) return;

        const input = group.querySelector(".mobilgo-switch-input");
        const buttons = group.querySelectorAll(".mobilgo-switch-btn");
        const value = button.getAttribute("data-value");

        buttons.forEach(function (btn) {
            btn.classList.remove("is-active");
        });

        button.classList.add("is-active");

        if (input) {
            input.value = value;
            input.dispatchEvent(new Event("change", { bubbles: true }));
        }

        document.dispatchEvent(new Event("mobilgo_switch_updated"));
    }

    function handleMediaUpload(button) {
        const field = button.closest(".mobilgo-field");
        if (!field || typeof wp === "undefined" || !wp.media) return;

        const input = field.querySelector(".mobilgo-media-input");
        const preview = field.querySelector(".mobilgo-media-preview");
        const previewImg = preview ? preview.querySelector("img") : null;

        const frame = wp.media({
            title: "Choose image",
            button: { text: "Use image" },
            multiple: false
        });

        frame.on("select", function () {
            const attachment = frame.state().get("selection").first().toJSON();

            if (input) {
                input.value = attachment.url || "";
                input.dispatchEvent(new Event("change", { bubbles: true }));
            }

            if (preview && previewImg) {
                preview.style.display = "block";
                previewImg.src = attachment.url || "";
            }
        });

        frame.open();
    }

    function handleMediaRemove(button) {
        const field = button.closest(".mobilgo-field");
        if (!field) return;

        const input = field.querySelector(".mobilgo-media-input");
        const preview = field.querySelector(".mobilgo-media-preview");
        const previewImg = preview ? preview.querySelector("img") : null;

        if (input) {
            input.value = "";
            input.dispatchEvent(new Event("change", { bubbles: true }));
        }

        if (preview) {
            preview.style.display = "none";
        }

        if (previewImg) {
            previewImg.src = "";
        }
    }

    function resetColor(button) {
        const wrap = button.closest(".mobilgo-color-wrap");
        if (!wrap) return;

        const input = wrap.querySelector(".mobilgo-color-input");
        const defaultValue = button.getAttribute("data-default") || "#111111";

        if (input) {
            input.value = defaultValue;
            input.dispatchEvent(new Event("change", { bubbles: true }));
            input.dispatchEvent(new Event("input", { bubbles: true }));
        }
    }

    function resetDefaults(button) {
        const scope = button.closest(".mobilgo-admin-wrap") || document;

        const fields = scope.querySelectorAll(
            "input[data-default], textarea[data-default], select[data-default]"
        );

        fields.forEach(function (field) {
            const defaultValue = field.getAttribute("data-default");

            if (field.type === "checkbox") {
                field.checked =
                    defaultValue === "1" ||
                    defaultValue === "yes" ||
                    defaultValue === "true";
            } else if (field.type === "radio") {
                field.checked = field.value === defaultValue;
            } else {
                field.value = defaultValue !== null ? defaultValue : "";
            }

            field.dispatchEvent(new Event("change", { bubbles: true }));
            field.dispatchEvent(new Event("input", { bubbles: true }));
        });

        const switchGroups = scope.querySelectorAll(".mobilgo-switch-group");
        switchGroups.forEach(function (group) {
            const input = group.querySelector(".mobilgo-switch-input");
            const buttons = group.querySelectorAll(".mobilgo-switch-btn");

            if (!input) return;

            buttons.forEach(function (btn) {
                btn.classList.remove("is-active");

                if (btn.getAttribute("data-value") === input.value) {
                    btn.classList.add("is-active");
                }
            });
        });

        const iconPickers = scope.querySelectorAll(".mobilgo-icon-picker");
        iconPickers.forEach(function (picker) {
            const input = picker.querySelector(".mobilgo-icon-input");
            const typeInput = picker.querySelector(".mobilgo-icon-type-input");

            const defaultValue = input ? input.getAttribute("data-default") || "" : "";
            const defaultType = typeInput ? typeInput.getAttribute("data-default") || "fa" : "fa";

            updatePickerPreview(picker, defaultType, defaultValue);
        });

        const mediaFields = scope.querySelectorAll(".mobilgo-media-input");
        mediaFields.forEach(function (input) {
            const defaultValue = input.getAttribute("data-default") || "";
            const field = input.closest(".mobilgo-field");
            const preview = field ? field.querySelector(".mobilgo-media-preview") : null;
            const previewImg = preview ? preview.querySelector("img") : null;

            input.value = defaultValue;
            input.dispatchEvent(new Event("change", { bubbles: true }));

            if (preview && previewImg) {
                if (defaultValue) {
                    preview.style.display = "block";
                    previewImg.src = defaultValue;
                } else {
                    preview.style.display = "none";
                    previewImg.src = "";
                }
            }
        });

        const colorResets = scope.querySelectorAll(".mobilgo-color-reset");
        colorResets.forEach(function (resetBtn) {
            const wrap = resetBtn.closest(".mobilgo-color-wrap");
            const input = wrap ? wrap.querySelector(".mobilgo-color-input") : null;
            const defaultValue = resetBtn.getAttribute("data-default") || "#111111";

            if (input) {
                input.value = defaultValue;
                input.dispatchEvent(new Event("change", { bubbles: true }));
                input.dispatchEvent(new Event("input", { bubbles: true }));
            }
        });

        toggleConditionalFields();
    }

    function toggleConditionalFields() {
        const transparentInput = document.querySelector(
            'input[name="mobilgo_header_transparent_enable"]'
        );
        const transparentWrap = document.querySelector(".mobilgo-transparent-conditional");

        if (transparentInput && transparentWrap) {
            transparentWrap.style.display =
                transparentInput.value === "no" ? "block" : "none";
        }
    }

    document.addEventListener("click", function (e) {
        const switchBtn = e.target.closest(".mobilgo-switch-btn");
        if (switchBtn) {
            e.preventDefault();
            toggleSwitchButton(switchBtn);
            return;
        }

        const uploadBtn = e.target.closest(".mobilgo-upload-button");
        if (uploadBtn) {
            e.preventDefault();
            handleMediaUpload(uploadBtn);
            return;
        }

        const removeBtn = e.target.closest(".mobilgo-remove-button");
        if (removeBtn) {
            e.preventDefault();
            handleMediaRemove(removeBtn);
            return;
        }

        const chooseIconBtn = e.target.closest(".mobilgo-choose-icon-button");
        if (chooseIconBtn) {
            e.preventDefault();
            const picker = chooseIconBtn.closest(".mobilgo-icon-picker");
            openIconModal(picker);
            return;
        }

        const removeIconBtn = e.target.closest(".mobilgo-remove-icon-button");
        if (removeIconBtn) {
            e.preventDefault();
            const picker = removeIconBtn.closest(".mobilgo-icon-picker");
            updatePickerPreview(picker, "fa", "");
            return;
        }

        const iconItem = e.target.closest(".mobilgo-icon-item");
        if (iconItem) {
            e.preventDefault();

            if (activeIconPicker) {
                const type = iconItem.getAttribute("data-type") || "fa";
                const value = iconItem.getAttribute("data-value") || "";
                updatePickerPreview(activeIconPicker, type, value);
            }

            closeIconModal();
            return;
        }

        const colorResetBtn = e.target.closest(".mobilgo-color-reset");
        if (colorResetBtn) {
            e.preventDefault();
            resetColor(colorResetBtn);
            return;
        }

        const resetDefaultsBtn = e.target.closest(".mobilgo-reset-button");
        if (resetDefaultsBtn) {
            e.preventDefault();
            resetDefaults(resetDefaultsBtn);
            return;
        }

        if (
            e.target.classList.contains("mobilgo-icon-modal__close") ||
            e.target.classList.contains("mobilgo-icon-modal__overlay")
        ) {
            e.preventDefault();
            closeIconModal();
        }
    });

    document.addEventListener("input", function (e) {
        if (e.target && e.target.id === "mobilgo-icon-search") {
            renderIconGrid(e.target.value || "");
        }
    });

    document.addEventListener("mobilgo_switch_updated", toggleConditionalFields);
    toggleConditionalFields();
});
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* =========================
   Company Info
========================= */

function mobilgo_get_company_name() {
    return get_option('mobilgo_company_name', 'MobilGo');
}

function mobilgo_get_phone() {
    return get_option('mobilgo_company_phone', '');
}

function mobilgo_get_email() {
    return get_option('mobilgo_company_email', '');
}

function mobilgo_get_address() {
    return get_option('mobilgo_company_address', '');
}


/* =========================
   Locations (max 6)
========================= */

function mobilgo_get_locations() {

    $locations = array();

    for ($i = 1; $i <= 6; $i++) {

        $title   = get_option("mobilgo_location_{$i}_title");
        $address = get_option("mobilgo_location_{$i}_address");
        $map     = get_option("mobilgo_location_{$i}_map");
        $phone   = get_option("mobilgo_location_{$i}_phone");
        $hours   = get_option("mobilgo_location_{$i}_hours");

        if ($title || $address) {

            $locations[] = array(
                'title'   => $title,
                'address' => $address,
                'map'     => $map,
                'phone'   => $phone,
                'hours'   => $hours,
            );

        }
    }

    return $locations;
}
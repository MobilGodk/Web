<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* =========================
   Icon List
========================= */

function mobilgo_get_icon_picker_items() {
    return array(

        /* =========================
           Location / Store
        ========================= */
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-location-dot',
            'label' => 'Location',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-map-location-dot',
            'label' => 'Map Location',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-map-pin',
            'label' => 'Map Pin',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-store',
            'label' => 'Store',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-shop',
            'label' => 'Shop',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-shop-lock',
            'label' => 'Shop Lock',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-building',
            'label' => 'Building',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-warehouse',
            'label' => 'Warehouse',
        ),

        /* =========================
           Contact
        ========================= */
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-phone',
            'label' => 'Phone',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-phone-volume',
            'label' => 'Phone Volume',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-mobile',
            'label' => 'Mobile',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-mobile-screen',
            'label' => 'Mobile Screen',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-mobile-screen-button',
            'label' => 'Mobile Button',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-envelope',
            'label' => 'Mail',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-envelope-open',
            'label' => 'Mail Open',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-comment',
            'label' => 'Comment',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-comments',
            'label' => 'Comments',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-brands fa-whatsapp',
            'label' => 'WhatsApp',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-brands fa-facebook-messenger',
            'label' => 'Messenger',
        ),

        /* =========================
           Time / Booking
        ========================= */
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-clock',
            'label' => 'Clock',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-regular fa-clock',
            'label' => 'Clock Regular',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-calendar',
            'label' => 'Calendar',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-calendar-days',
            'label' => 'Calendar Days',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-calendar-check',
            'label' => 'Calendar Check',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-hourglass',
            'label' => 'Hourglass',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-stopwatch',
            'label' => 'Stopwatch',
        ),

        /* =========================
           Devices
        ========================= */
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-mobile-screen',
            'label' => 'Smartphone',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-tablet-screen-button',
            'label' => 'Tablet',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-laptop',
            'label' => 'Laptop',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-desktop',
            'label' => 'Desktop',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-computer',
            'label' => 'Computer',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-keyboard',
            'label' => 'Keyboard',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-mouse',
            'label' => 'Mouse',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-print',
            'label' => 'Printer',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-tv',
            'label' => 'TV',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-display',
            'label' => 'Display',
        ),

        /* =========================
           Wearables / Audio
        ========================= */
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-clock',
            'label' => 'Watch',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-headphones',
            'label' => 'Headphones',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-headset',
            'label' => 'Headset',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-ear-listen',
            'label' => 'Ear',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-volume-high',
            'label' => 'Volume',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-microphone',
            'label' => 'Microphone',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-camera',
            'label' => 'Camera',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-camera-retro',
            'label' => 'Camera Retro',
        ),

        /* =========================
           Charging / Battery / Power
        ========================= */
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-battery-full',
            'label' => 'Battery Full',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-battery-half',
            'label' => 'Battery Half',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-battery-quarter',
            'label' => 'Battery Low',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-battery-empty',
            'label' => 'Battery Empty',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-plug',
            'label' => 'Plug',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-bolt',
            'label' => 'Bolt',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-charging-station',
            'label' => 'Charging Station',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-power-off',
            'label' => 'Power',
        ),

        /* =========================
           Repair / Service
        ========================= */
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-screwdriver-wrench',
            'label' => 'Repair',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-screwdriver',
            'label' => 'Screwdriver',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-wrench',
            'label' => 'Wrench',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-toolbox',
            'label' => 'Toolbox',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-gears',
            'label' => 'Gears',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-microchip',
            'label' => 'Chip',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-hard-drive',
            'label' => 'Hard Drive',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-memory',
            'label' => 'Memory',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-sim-card',
            'label' => 'SIM Card',
        ),

        /* =========================
           Security / Safe
        ========================= */
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-shield',
            'label' => 'Shield',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-shield-halved',
            'label' => 'Shield Safe',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-lock',
            'label' => 'Lock',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-unlock',
            'label' => 'Unlock',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-key',
            'label' => 'Key',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-user-shield',
            'label' => 'User Shield',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-fingerprint',
            'label' => 'Fingerprint',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-eye',
            'label' => 'Eye',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-eye-slash',
            'label' => 'Eye Slash',
        ),

        /* =========================
           Sell / Buy / Money
        ========================= */
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-cart-shopping',
            'label' => 'Cart',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-bag-shopping',
            'label' => 'Shopping Bag',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-cash-register',
            'label' => 'Cash Register',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-credit-card',
            'label' => 'Card',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-money-bill',
            'label' => 'Money',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-money-bill-wave',
            'label' => 'Money Wave',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-coins',
            'label' => 'Coins',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-receipt',
            'label' => 'Receipt',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-tag',
            'label' => 'Tag',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-tags',
            'label' => 'Tags',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-percent',
            'label' => 'Discount',
        ),

        /* =========================
           Delivery / Service Flow
        ========================= */
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-truck',
            'label' => 'Truck',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-box',
            'label' => 'Box',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-box-open',
            'label' => 'Box Open',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-route',
            'label' => 'Route',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-check',
            'label' => 'Check',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-circle-check',
            'label' => 'Check Circle',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-circle-xmark',
            'label' => 'Close Circle',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-triangle-exclamation',
            'label' => 'Warning',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-circle-info',
            'label' => 'Info',
        ),

        /* =========================
           Menu / UI
        ========================= */
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-bars',
            'label' => 'Menu',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-xmark',
            'label' => 'Close',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-magnifying-glass',
            'label' => 'Search',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-house',
            'label' => 'Home',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-user',
            'label' => 'User',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-users',
            'label' => 'Users',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-star',
            'label' => 'Star',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-heart',
            'label' => 'Heart',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-thumbs-up',
            'label' => 'Thumbs Up',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-solid fa-gear',
            'label' => 'Settings',
        ),

        /* =========================
           Social / Brands
        ========================= */
        array(
            'type'  => 'fa',
            'value' => 'fa-brands fa-apple',
            'label' => 'Apple',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-brands fa-android',
            'label' => 'Android',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-brands fa-google',
            'label' => 'Google',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-brands fa-facebook-f',
            'label' => 'Facebook',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-brands fa-instagram',
            'label' => 'Instagram',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-brands fa-tiktok',
            'label' => 'TikTok',
        ),
        array(
            'type'  => 'fa',
            'value' => 'fa-brands fa-youtube',
            'label' => 'YouTube',
        ),

        /* =========================
           SVG placeholders
        ========================= */
        array(
            'type'  => 'svg',
            'value' => 'phone',
            'label' => 'Phone SVG',
        ),
        array(
            'type'  => 'svg',
            'value' => 'mail',
            'label' => 'Mail SVG',
        ),
        array(
            'type'  => 'svg',
            'value' => 'location',
            'label' => 'Location SVG',
        ),
        array(
            'type'  => 'svg',
            'value' => 'clock',
            'label' => 'Clock SVG',
        ),
    );
}

/* =========================
   Get SVG Icon Path
========================= */

function mobilgo_get_svg_icon_path( $slug ) {
    $slug = sanitize_file_name( $slug );

    if ( empty( $slug ) ) {
        return '';
    }

    $path = get_template_directory() . '/assets/icons/' . $slug . '.svg';

    if ( file_exists( $path ) && is_readable( $path ) ) {
        return $path;
    }

    return '';
}

/* =========================
   Render SVG Icon
========================= */

function mobilgo_render_svg_icon( $slug, $class = '' ) {
    $path = mobilgo_get_svg_icon_path( $slug );

    if ( empty( $path ) ) {
        return '';
    }

    $svg = file_get_contents( $path );

    if ( false === $svg || empty( $svg ) ) {
        return '';
    }

    if ( ! empty( $class ) ) {
        $svg = preg_replace(
            '/<svg\b([^>]*)>/',
            '<svg$1 class="' . esc_attr( $class ) . '">',
            $svg,
            1
        );
    }

    return $svg;
}

/* =========================
   Render Any Icon
========================= */

function mobilgo_render_icon( $icon = '', $type = 'fa', $class = '' ) {
    if ( empty( $icon ) ) {
        return '';
    }

    if ( 'svg' === $type ) {
        return mobilgo_render_svg_icon( $icon, $class );
    }

    $class_attr = ! empty( $class ) ? ' ' . $class : '';

    return '<i class="' . esc_attr( $icon . $class_attr ) . '" aria-hidden="true"></i>';
}
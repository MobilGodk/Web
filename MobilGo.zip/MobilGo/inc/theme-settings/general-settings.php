<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* =========================
   Register General Settings
========================= */

function mobilgo_register_general_settings() {

    $settings = array(

        /* Business Info */
        'mobilgo_company_name',
        'mobilgo_company_phone',
        'mobilgo_company_email',
        'mobilgo_company_address',

        /* Locations */
        'mobilgo_location_1_title',
        'mobilgo_location_1_address',
        'mobilgo_location_1_map',
        'mobilgo_location_1_phone',
        'mobilgo_location_1_hours',

        'mobilgo_location_2_title',
        'mobilgo_location_2_address',
        'mobilgo_location_2_map',
        'mobilgo_location_2_phone',
        'mobilgo_location_2_hours',

        'mobilgo_location_3_title',
        'mobilgo_location_3_address',
        'mobilgo_location_3_map',
        'mobilgo_location_3_phone',
        'mobilgo_location_3_hours',

        'mobilgo_location_4_title',
        'mobilgo_location_4_address',
        'mobilgo_location_4_map',
        'mobilgo_location_4_phone',
        'mobilgo_location_4_hours',

        'mobilgo_location_5_title',
        'mobilgo_location_5_address',
        'mobilgo_location_5_map',
        'mobilgo_location_5_phone',
        'mobilgo_location_5_hours',

        'mobilgo_location_6_title',
        'mobilgo_location_6_address',
        'mobilgo_location_6_map',
        'mobilgo_location_6_phone',
        'mobilgo_location_6_hours',

        /* Preloader */
        'mobilgo_enable_preloader',
        'mobilgo_loading_text',
        'mobilgo_site_preloader',

        /* Colors */
        'mobilgo_primary_color',
        'mobilgo_primary_hover_color',
        'mobilgo_text_color',
        'mobilgo_text_light_color',
        'mobilgo_box_bg_color',
        'mobilgo_border_color',
        'mobilgo_tag_bg_color',
        'mobilgo_icon_color',
        'mobilgo_icon_hover_color',
        'mobilgo_button_color',
        'mobilgo_button_hover_color',
        'mobilgo_button_text_color',
    );

    foreach ( $settings as $setting ) {
        register_setting( 'mobilgo_theme_settings_group', $setting );
    }
}
add_action( 'admin_init', 'mobilgo_register_general_settings' );

/* =========================
   Render General Settings Page
========================= */

function mobilgo_render_general_settings_page() {

    mobilgo_admin_settings_header(
        'General Settings',
        'Manage business info, locations, preloader settings and design colors.'
    );

    settings_errors( 'mobilgo_messages' );
    ?>

    <form method="post" action="options.php">
        <?php settings_fields( 'mobilgo_theme_settings_group' ); ?>

        <?php mobilgo_field_section_title(
            'Business Info',
            'Manage the main company details used across the website.'
        ); ?>

        <div class="mobilgo-settings-grid">
            <div class="mobilgo-settings-col">
                <?php
                mobilgo_field_text(
                    'Company Name',
                    'mobilgo_company_name',
                    'MobilGo',
                    'Main business name.',
                    'MobilGo'
                );

                mobilgo_field_text(
                    'Company Phone',
                    'mobilgo_company_phone',
                    '+45 22 66 66 69',
                    'Main phone number used across the website.',
                    ''
                );
                ?>
            </div>

            <div class="mobilgo-settings-col">
                <?php
                mobilgo_field_text(
                    'Company Email',
                    'mobilgo_company_email',
                    'info@mobilgo.dk',
                    'Main email address used across the website.',
                    ''
                );

                mobilgo_field_text(
                    'Main Address',
                    'mobilgo_company_address',
                    'Main street, city',
                    'Primary business address.',
                    ''
                );
                ?>
            </div>
        </div>

        <?php mobilgo_field_section_close(); ?>


        <?php mobilgo_field_section_title(
            'Locations',
            'Add up to 6 shop locations. Each location can have its own title, address, map link, phone and hours.'
        ); ?>

        <?php for ( $i = 1; $i <= 6; $i++ ) : ?>
            <div class="mobilgo-location-block">
                <h3 class="mobilgo-location-block__title"><?php echo esc_html( 'Location ' . $i ); ?></h3>

                <div class="mobilgo-settings-grid">
                    <div class="mobilgo-settings-col">
                        <?php
                        mobilgo_field_text(
                            'Location Title',
                            'mobilgo_location_' . $i . '_title',
                            'MobilGo Branch ' . $i,
                            'Branch title.',
                            ''
                        );

                        mobilgo_field_text(
                            'Location Address',
                            'mobilgo_location_' . $i . '_address',
                            'Street name, city',
                            'Full address for this location.',
                            ''
                        );

                        mobilgo_field_text(
                            'Google Maps Link',
                            'mobilgo_location_' . $i . '_map',
                            'https://maps.google.com/...',
                            'Optional Google Maps link.',
                            ''
                        );
                        ?>
                    </div>

                    <div class="mobilgo-settings-col">
                        <?php
                        mobilgo_field_text(
                            'Location Phone',
                            'mobilgo_location_' . $i . '_phone',
                            '+45 00 00 00 00',
                            'Optional phone for this location.',
                            ''
                        );

                        mobilgo_field_text(
                            'Opening Hours',
                            'mobilgo_location_' . $i . '_hours',
                            'Mon - Fri 10:00 - 18:00',
                            'Opening hours for this location.',
                            ''
                        );
                        ?>
                    </div>
                </div>
            </div>
        <?php endfor; ?>

        <?php mobilgo_field_section_close(); ?>


        <?php mobilgo_field_section_title(
            'Brand Settings',
            'Manage your preloader settings before the page loads.'
        ); ?>

        <div class="mobilgo-brand-grid">
            <div class="mobilgo-brand-left">
                <?php
                mobilgo_field_switch(
                    'Display preloader before page load',
                    'mobilgo_enable_preloader',
                    'Enable or disable site preloader.',
                    'no'
                );

                mobilgo_field_text(
                    'Loading Text',
                    'mobilgo_loading_text',
                    'MobilGo ...',
                    'Change loading text.',
                    'MobilGo ...'
                );
                ?>
            </div>

            <div class="mobilgo-brand-right">
                <?php
                mobilgo_field_media(
                    'Site Preloader',
                    'mobilgo_site_preloader',
                    'Add or upload preloader using the WordPress native uploader.'
                );
                ?>
            </div>
        </div>

        <?php mobilgo_field_section_close(); ?>


        <?php mobilgo_field_section_title(
            'Design Settings',
            'Control the main theme colors used across the website.'
        ); ?>

        <?php
        mobilgo_field_color(
            'Primary Color',
            'mobilgo_primary_color',
            'Main accent color for buttons, icons and highlights.',
            '#d10000'
        );

        mobilgo_field_color(
            'Primary Hover Color',
            'mobilgo_primary_hover_color',
            'Hover color for primary interactive elements.',
            '#a80000'
        );

        mobilgo_field_color(
            'Text Color',
            'mobilgo_text_color',
            'Main heading and strong text color.',
            '#111111'
        );

        mobilgo_field_color(
            'Text Light Color',
            'mobilgo_text_light_color',
            'Paragraph and secondary text color.',
            '#555555'
        );

        mobilgo_field_color(
            'Box Background Color',
            'mobilgo_box_bg_color',
            'Default card and box background color.',
            '#ffffff'
        );

        mobilgo_field_color(
            'Border Color',
            'mobilgo_border_color',
            'Default border color for cards and sections.',
            '#eeeeee'
        );

        mobilgo_field_color(
            'Tag Background Color',
            'mobilgo_tag_bg_color',
            'Background color for small badges and taglines.',
            '#efefef'
        );

        mobilgo_field_color(
            'Icon Color',
            'mobilgo_icon_color',
            'Default icon color across the website.',
            '#d10000'
        );

        mobilgo_field_color(
            'Icon Hover Color',
            'mobilgo_icon_hover_color',
            'Hover color for icons.',
            '#a80000'
        );

        mobilgo_field_color(
            'Button Color',
            'mobilgo_button_color',
            'Main button background color.',
            '#d10000'
        );

        mobilgo_field_color(
            'Button Hover Color',
            'mobilgo_button_hover_color',
            'Hover background color for buttons.',
            '#a80000'
        );

        mobilgo_field_color(
            'Button Text Color',
            'mobilgo_button_text_color',
            'Text color used inside buttons.',
            '#ffffff'
        );
        ?>

        <?php mobilgo_field_section_close(); ?>

        <?php mobilgo_admin_settings_actions(); ?>
    </form>

    <?php
    mobilgo_admin_settings_footer();
}
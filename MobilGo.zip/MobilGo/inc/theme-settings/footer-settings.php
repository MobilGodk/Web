<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* =========================
   Register Footer Settings
========================= */

function mobilgo_register_footer_settings() {
    register_setting(
        'mobilgo_footer_group',
        'mobilgo_footer_logo',
        array(
            'type'              => 'string',
            'sanitize_callback' => 'esc_url_raw',
        )
    );
    register_setting(
        'mobilgo_footer_group',
        'mobilgo_footer_text',
        array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_textarea_field',
        )
    );
}
add_action( 'admin_init', 'mobilgo_register_footer_settings' );


/* =========================
   Render Footer Page
========================= */

function mobilgo_render_footer_settings_page() {
    mobilgo_admin_settings_header(
        'Footer indstillinger',
        'Alle footer indstillinger.'
    );
    ?>
    <form method="post" action="<?php echo esc_url( admin_url( 'options.php' ) ); ?>">
        <?php settings_fields( 'mobilgo_footer_group' ); ?>

        <?php mobilgo_field_section_title( 'Footer', 'Footer settings for MobilGo' ); ?>
            <?php mobilgo_field_media( 'Footer Logo', 'mobilgo_footer_logo', 'Add/Upload footer logo' ); ?>
            <?php mobilgo_field_textarea( 'Footer Text', 'mobilgo_footer_text', 'Footer text here...', '', '' ); ?>
        <?php mobilgo_field_section_close(); ?>

        <?php submit_button( 'Save Changes' ); ?>
    </form>
    <?php
    mobilgo_admin_settings_footer();
}

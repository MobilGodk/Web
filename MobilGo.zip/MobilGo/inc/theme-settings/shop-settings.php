<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* =========================
   Register Shop Settings
========================= */

function mobilgo_register_shop_settings() {
    register_setting(
        'mobilgo_shop_group',
        'mobilgo_disable_cart_home',
        array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        )
    );
    register_setting(
        'mobilgo_shop_group',
        'mobilgo_disable_cart_full_site',
        array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        )
    );
    register_setting(
        'mobilgo_shop_group',
        'mobilgo_enable_cart_mobile',
        array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        )
    );
}
add_action( 'admin_init', 'mobilgo_register_shop_settings' );


/* =========================
   Render Shop Page
========================= */

function mobilgo_render_shop_settings_page() {
    mobilgo_admin_settings_header(
        'Butik indstillinger',
        'Alle shop indstillinger.'
    );
    ?>
    <form method="post" action="<?php echo esc_url( admin_url( 'options.php' ) ); ?>">
        <?php settings_fields( 'mobilgo_shop_group' ); ?>

        <?php mobilgo_field_section_title( 'Shop Settings', 'Cart visibility settings' ); ?>
            <?php mobilgo_field_switch( 'Disable Cart in Home', 'mobilgo_disable_cart_home', 'Enable or Disable the cart button in home page', 'no' ); ?>
            <?php mobilgo_field_switch( 'Disable Cart in Full Site', 'mobilgo_disable_cart_full_site', 'Disable or Enable the cart button in full Site', 'no' ); ?>
            <?php mobilgo_field_switch( 'Enable Cart Always in Mobile', 'mobilgo_enable_cart_mobile', 'Enable or Disable the cart button Always in Mobile', 'yes' ); ?>
        <?php mobilgo_field_section_close(); ?>

        <?php submit_button( 'Save Changes' ); ?>
    </form>
    <?php
    mobilgo_admin_settings_footer();
}

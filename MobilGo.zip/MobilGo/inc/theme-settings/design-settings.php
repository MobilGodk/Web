<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* =========================
   Register Design Settings
========================= */

function mobilgo_register_design_settings() {

    /* Main Colors */
    register_setting( 'mobilgo_theme_settings_group', 'mobilgo_primary_color' );
    register_setting( 'mobilgo_theme_settings_group', 'mobilgo_primary_hover_color' );

    /* Text Colors */
    register_setting( 'mobilgo_theme_settings_group', 'mobilgo_text_color' );
    register_setting( 'mobilgo_theme_settings_group', 'mobilgo_text_light_color' );

    /* Background & Borders */
    register_setting( 'mobilgo_theme_settings_group', 'mobilgo_box_bg_color' );
    register_setting( 'mobilgo_theme_settings_group', 'mobilgo_border_color' );

    /* Tag / Badge */
    register_setting( 'mobilgo_theme_settings_group', 'mobilgo_tag_bg_color' );

    /* Icons */
    register_setting( 'mobilgo_theme_settings_group', 'mobilgo_icon_color' );
    register_setting( 'mobilgo_theme_settings_group', 'mobilgo_icon_hover_color' );

    /* Buttons */
    register_setting( 'mobilgo_theme_settings_group', 'mobilgo_button_color' );
    register_setting( 'mobilgo_theme_settings_group', 'mobilgo_button_hover_color' );

}

add_action( 'admin_init', 'mobilgo_register_design_settings' );
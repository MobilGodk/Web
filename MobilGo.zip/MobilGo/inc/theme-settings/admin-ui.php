<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* =========================
   Admin Assets
========================= */

function mobilgo_theme_settings_admin_assets( $hook ) {

    /* Load admin CSS everywhere so MobilGo menu stays styled */
    wp_enqueue_style(
        'mobilgo-admin-ui',
        get_template_directory_uri() . '/assets/admin/css/admin-ui.css',
        array(),
        file_exists( get_template_directory() . '/assets/admin/css/admin-ui.css' )
            ? filemtime( get_template_directory() . '/assets/admin/css/admin-ui.css' )
            : '1.0'
    );

    /* Only load media / icons / JS on MobilGo pages */
    if ( strpos( $hook, 'mobilgo-' ) === false ) {
        return;
    }

    wp_enqueue_media();

    wp_enqueue_style(
        'font-awesome',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css',
        array(),
        '6.5.1'
    );

    wp_enqueue_script(
        'mobilgo-admin-ui',
        get_template_directory_uri() . '/assets/admin/js/admin-ui.js',
        array( 'jquery' ),
        file_exists( get_template_directory() . '/assets/admin/js/admin-ui.js' )
            ? filemtime( get_template_directory() . '/assets/admin/js/admin-ui.js' )
            : '1.0',
        true
    );

    if ( function_exists( 'mobilgo_get_icon_picker_items' ) ) {
        wp_localize_script(
            'mobilgo-admin-ui',
            'mobilgoAdminIcons',
            array(
                'items' => mobilgo_get_icon_picker_items(),
            )
        );
    } else {
        wp_localize_script(
            'mobilgo-admin-ui',
            'mobilgoAdminIcons',
            array(
                'items' => array(),
            )
        );
    }
}
add_action( 'admin_enqueue_scripts', 'mobilgo_theme_settings_admin_assets' );

/* =========================
   Reset Theme Settings
========================= */

function mobilgo_reset_theme_settings() {
    if ( ! isset( $_POST['mobilgo_reset_defaults'] ) ) {
        return;
    }

    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    check_admin_referer( 'mobilgo_reset_defaults_action', 'mobilgo_reset_defaults_nonce' );

    $defaults = array(
        'mobilgo_primary_color'           => '#d10000',
        'mobilgo_primary_hover_color'     => '#a80000',
        'mobilgo_text_color'              => '#111111',
        'mobilgo_text_light_color'        => '#555555',
        'mobilgo_box_bg_color'            => '#ffffff',
        'mobilgo_border_color'            => '#eeeeee',
        'mobilgo_tag_bg_color'            => '#efefef',
        'mobilgo_button_text_color'       => '#ffffff',
        'mobilgo_icon_color'              => '#d10000',
        'mobilgo_icon_hover_color'        => '#a80000',
        'mobilgo_button_color'            => '#d10000',
        'mobilgo_button_hover_color'      => '#a80000',
        'mobilgo_page_bg_color'           => '#ffffff',
        'mobilgo_section_bg_color'        => '#ffffff',
        'mobilgo_button_bg_color'         => '#d10000',
        'mobilgo_button_hover_bg_color'   => '#a80000',
        'mobilgo_button_hover_text_color' => '#ffffff',
        'mobilgo_tag_text_color'          => '#111111',
    );

    foreach ( $defaults as $option_name => $default_value ) {
        update_option( $option_name, $default_value );
    }

    add_settings_error(
        'mobilgo_messages',
        'mobilgo_reset_success',
        'Theme defaults have been restored.',
        'updated'
    );
}
add_action( 'admin_init', 'mobilgo_reset_theme_settings' );

/* =========================
   Admin Menu
========================= */

function mobilgo_theme_settings_menu() {
    add_menu_page(
        'MobilGo Theme Settings',
        'MobilGo',
        'manage_options',
        'mobilgo-general-settings',
        'mobilgo_render_general_settings_page',
        'dashicons-smartphone',
        3
    );

    add_submenu_page(
        'mobilgo-general-settings',
        'General Settings',
        'General Settings',
        'manage_options',
        'mobilgo-general-settings',
        'mobilgo_render_general_settings_page'
    );

    add_submenu_page(
        'mobilgo-general-settings',
        'Header Settings',
        'Header Settings',
        'manage_options',
        'mobilgo-header-settings',
        'mobilgo_render_header_settings_page'
    );

    add_submenu_page(
        'mobilgo-general-settings',
        'Footer Settings',
        'Footer Settings',
        'manage_options',
        'mobilgo-footer-settings',
        'mobilgo_render_footer_settings_page'
    );

    add_submenu_page(
        'mobilgo-general-settings',
        'Shop Settings',
        'Shop Settings',
        'manage_options',
        'mobilgo-shop-settings',
        'mobilgo_render_shop_settings_page'
    );

    add_submenu_page(
        'mobilgo-general-settings',
        'Updates',
        'Updates',
        'manage_options',
        'mobilgo-updates',
        'mobilgo_render_updates_page'
    );
}
add_action( 'admin_menu', 'mobilgo_theme_settings_menu' );

/* =========================
   Shared Layout
========================= */

function mobilgo_admin_settings_header( $title, $description = '' ) {
    $current_page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
    $theme        = wp_get_theme();
    $theme_name   = $theme->get( 'Name' );
    $theme_ver    = $theme->get( 'Version' );
    ?>
    <div class="mobilgo-admin-wrap mobilgo-page-<?php echo esc_attr( $current_page ); ?>">
        <div class="mobilgo-admin-header">
            <div class="mobilgo-admin-header__top">
                <div class="mobilgo-admin-header__content">
                    <h1>Mobil<span>Go</span></h1>

                    <p>
                        <?php echo esc_html( $title ); ?>
                        <?php if ( ! empty( $description ) ) : ?>
                            — <?php echo esc_html( $description ); ?>
                        <?php endif; ?>
                    </p>
                </div>

                <div class="mobilgo-admin-theme-badge">
                    <span class="mobilgo-admin-theme-badge__name"><?php echo esc_html( $theme_name ); ?></span>
                    <span class="mobilgo-admin-theme-badge__version">v<?php echo esc_html( $theme_ver ); ?></span>
                </div>
            </div>
        </div>

        <div class="mobilgo-admin-grid">
            <aside class="mobilgo-admin-sidebar">
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=mobilgo-general-settings' ) ); ?>" class="<?php echo ( 'mobilgo-general-settings' === $current_page ) ? 'is-active' : ''; ?>">
                    General Settings
                </a>

                <a href="<?php echo esc_url( admin_url( 'admin.php?page=mobilgo-header-settings' ) ); ?>" class="<?php echo ( 'mobilgo-header-settings' === $current_page ) ? 'is-active' : ''; ?>">
                    Header Settings
                </a>

                <a href="<?php echo esc_url( admin_url( 'admin.php?page=mobilgo-footer-settings' ) ); ?>" class="<?php echo ( 'mobilgo-footer-settings' === $current_page ) ? 'is-active' : ''; ?>">
                    Footer Settings
                </a>

                <a href="<?php echo esc_url( admin_url( 'admin.php?page=mobilgo-shop-settings' ) ); ?>" class="<?php echo ( 'mobilgo-shop-settings' === $current_page ) ? 'is-active' : ''; ?>">
                    Shop Settings
                </a>

                <a href="<?php echo esc_url( admin_url( 'admin.php?page=mobilgo-updates' ) ); ?>" class="<?php echo ( 'mobilgo-updates' === $current_page ) ? 'is-active' : ''; ?>">
                    Updates
                </a>
            </aside>

            <main class="mobilgo-admin-content">
    <?php
}

function mobilgo_admin_settings_footer() {
    ?>
            </main>
        </div>
    </div>

    <div class="mobilgo-icon-modal" id="mobilgo-icon-modal" style="display:none;">
        <div class="mobilgo-icon-modal__overlay"></div>

        <div class="mobilgo-icon-modal__box">
            <div class="mobilgo-icon-modal__top">
                <h3>Choose Icon</h3>
                <button type="button" class="mobilgo-icon-modal__close">×</button>
            </div>

            <div class="mobilgo-icon-modal__search-wrap">
                <input type="text" id="mobilgo-icon-search" placeholder="Search icon...">
            </div>

            <div class="mobilgo-icon-grid" id="mobilgo-icon-grid"></div>
        </div>
    </div>
    <?php
}

/* =========================
   Action Buttons
========================= */

function mobilgo_admin_settings_actions() {
    ?>
    <div class="mobilgo-admin-actions">
        <button
            type="submit"
            name="mobilgo_reset_defaults"
            value="1"
            class="mobilgo-reset-button"
            onclick="return confirm('Are you sure you want to restore the default theme settings?');"
        >
            <span class="dashicons dashicons-update-alt"></span>
            Reset Defaults
        </button>

        <button type="submit" class="mobilgo-save-button">
            <span class="dashicons dashicons-saved"></span>
            Save Changes
        </button>

        <?php wp_nonce_field( 'mobilgo_reset_defaults_action', 'mobilgo_reset_defaults_nonce' ); ?>
    </div>
    <?php
}

/* =========================
   Field Helpers
========================= */

function mobilgo_field_switch( $label, $name, $description = '', $default = 'no' ) {
    $value = get_option( $name, $default );
    ?>
    <div class="mobilgo-field">
        <label><?php echo esc_html( $label ); ?></label>

        <?php if ( ! empty( $description ) ) : ?>
            <p class="mobilgo-field-description"><?php echo esc_html( $description ); ?></p>
        <?php endif; ?>

        <div class="mobilgo-switch-group">
            <input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" class="mobilgo-switch-input">

            <button type="button" class="mobilgo-switch-btn <?php echo ( 'yes' === $value ) ? 'is-active' : ''; ?>" data-value="yes">
                Enable
            </button>

            <button type="button" class="mobilgo-switch-btn <?php echo ( 'no' === $value ) ? 'is-active' : ''; ?>" data-value="no">
                Disable
            </button>
        </div>
    </div>
    <?php
}

function mobilgo_field_select( $label, $name, $options = array(), $description = '', $default = '' ) {
    $value = get_option( $name, $default );
    ?>
    <div class="mobilgo-field">
        <label for="<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $label ); ?></label>

        <?php if ( ! empty( $description ) ) : ?>
            <p class="mobilgo-field-description"><?php echo esc_html( $description ); ?></p>
        <?php endif; ?>

        <select id="<?php echo esc_attr( $name ); ?>" name="<?php echo esc_attr( $name ); ?>">
            <?php foreach ( $options as $key => $option_label ) : ?>
                <option value="<?php echo esc_attr( $key ); ?>" <?php selected( $value, $key ); ?>>
                    <?php echo esc_html( $option_label ); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <?php
}

function mobilgo_field_text( $label, $name, $placeholder = '', $description = '', $default = '' ) {
    $value = get_option( $name, $default );
    ?>
    <div class="mobilgo-field">
        <label for="<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $label ); ?></label>

        <?php if ( ! empty( $description ) ) : ?>
            <p class="mobilgo-field-description"><?php echo esc_html( $description ); ?></p>
        <?php endif; ?>

        <input
            type="text"
            id="<?php echo esc_attr( $name ); ?>"
            name="<?php echo esc_attr( $name ); ?>"
            value="<?php echo esc_attr( $value ); ?>"
            placeholder="<?php echo esc_attr( $placeholder ); ?>"
        >
    </div>
    <?php
}

function mobilgo_field_color( $label, $name, $description = '', $default = '#111111' ) {
    $value = get_option( $name, $default );
    ?>
    <div class="mobilgo-field mobilgo-color-field">
        <label for="<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $label ); ?></label>

        <?php if ( ! empty( $description ) ) : ?>
            <p class="mobilgo-field-description"><?php echo esc_html( $description ); ?></p>
        <?php endif; ?>

        <div class="mobilgo-color-wrap">
            <input
                type="color"
                id="<?php echo esc_attr( $name ); ?>"
                name="<?php echo esc_attr( $name ); ?>"
                value="<?php echo esc_attr( $value ); ?>"
                data-default="<?php echo esc_attr( $default ); ?>"
                class="mobilgo-color-input"
            >

            <button
                type="button"
                class="mobilgo-color-reset"
                data-default="<?php echo esc_attr( $default ); ?>"
            >
                Reset
            </button>
        </div>
    </div>
    <?php
}

function mobilgo_field_textarea( $label, $name, $placeholder = '', $description = '', $default = '' ) {
    $value = get_option( $name, $default );
    ?>
    <div class="mobilgo-field">
        <label for="<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $label ); ?></label>

        <?php if ( ! empty( $description ) ) : ?>
            <p class="mobilgo-field-description"><?php echo esc_html( $description ); ?></p>
        <?php endif; ?>

        <textarea
            id="<?php echo esc_attr( $name ); ?>"
            name="<?php echo esc_attr( $name ); ?>"
            rows="4"
            placeholder="<?php echo esc_attr( $placeholder ); ?>"
        ><?php echo esc_textarea( $value ); ?></textarea>
    </div>
    <?php
}

function mobilgo_field_media( $label, $name, $description = '' ) {
    $value = get_option( $name, '' );
    ?>
    <div class="mobilgo-field">
        <label><?php echo esc_html( $label ); ?></label>

        <?php if ( ! empty( $description ) ) : ?>
            <p class="mobilgo-field-description"><?php echo esc_html( $description ); ?></p>
        <?php endif; ?>

        <div class="mobilgo-media-wrap">
            <input type="text" class="mobilgo-media-input" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>">
        </div>

        <div class="mobilgo-media-preview" <?php echo empty( $value ) ? 'style="display:none;"' : ''; ?>>
            <img src="<?php echo esc_url( $value ); ?>" alt="">
        </div>

        <div class="mobilgo-media-actions">
            <button type="button" class="button mobilgo-upload-button">Upload</button>
            <button type="button" class="button mobilgo-remove-button">Remove</button>
        </div>
    </div>
    <?php
}

function mobilgo_field_icon_picker( $label, $name, $description = '', $default = 'fa-solid fa-location-dot', $default_type = 'fa' ) {
    $value      = get_option( $name, $default );
    $type_name  = $name . '_type';
    $type_value = get_option( $type_name, $default_type );
    ?>
    <div class="mobilgo-field">
        <label><?php echo esc_html( $label ); ?></label>

        <?php if ( ! empty( $description ) ) : ?>
            <p class="mobilgo-field-description"><?php echo esc_html( $description ); ?></p>
        <?php endif; ?>

        <div class="mobilgo-icon-picker" data-target="<?php echo esc_attr( $name ); ?>" data-target-type="<?php echo esc_attr( $type_name ); ?>">
            <input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" class="mobilgo-icon-input">
            <input type="hidden" name="<?php echo esc_attr( $type_name ); ?>" value="<?php echo esc_attr( $type_value ); ?>" class="mobilgo-icon-type-input">

            <div class="mobilgo-icon-preview">
                <?php
                if ( ! empty( $value ) && function_exists( 'mobilgo_render_icon' ) ) {
                    echo mobilgo_render_icon( $value, $type_value ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                } else {
                    echo '<span>No icon</span>';
                }
                ?>
            </div>

            <div class="mobilgo-icon-picker-actions">
                <button type="button" class="button mobilgo-choose-icon-button">Choose Icon</button>
                <button type="button" class="button mobilgo-remove-icon-button">Remove</button>
            </div>

            <div class="mobilgo-icon-class-text">
                <code><?php echo esc_html( $type_value . ':' . $value ); ?></code>
            </div>
        </div>
    </div>
    <?php
}

function mobilgo_field_section_title( $title, $desc = '' ) {
    ?>
    <div class="mobilgo-card">
        <h2><?php echo esc_html( $title ); ?></h2>

        <?php if ( ! empty( $desc ) ) : ?>
            <p class="mobilgo-card-description"><?php echo esc_html( $desc ); ?></p>
        <?php endif; ?>
    <?php
}

function mobilgo_field_section_close() {
    echo '</div>';
}

/* =========================
   Updates Page
========================= */

function mobilgo_render_updates_page() {
    mobilgo_admin_settings_header(
        'Updates',
        'This section is reserved for future theme updates, changelogs and version notices.'
    );
    ?>
    <div class="mobilgo-card">
        <h2>Theme Updates</h2>
        <p class="mobilgo-card-description">
            This page is ready for future use.
        </p>

        <div class="mobilgo-update-placeholder">
            <p><strong>Current status:</strong> No update system has been connected yet.</p>
            <p>You can later use this page for:</p>
            <ul>
                <li>Theme version changelog</li>
                <li>Manual update notes</li>
                <li>Important notices</li>
                <li>Remote update system</li>
            </ul>
        </div>
    </div>
    <?php
    mobilgo_admin_settings_footer();
}
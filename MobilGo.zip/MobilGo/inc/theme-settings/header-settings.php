<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* =========================
   Register Header Settings
========================= */

function mobilgo_register_header_settings() {

    $fields = array(

        /* Header Design */
        'mobilgo_header_design_type'        => 'sanitize_text_field',

        /* Transparent Header */
        'mobilgo_header_transparent_enable' => 'sanitize_text_field',
        'mobilgo_header_background_type'    => 'sanitize_text_field',
        'mobilgo_header_background_color'   => 'sanitize_hex_color',
        'mobilgo_header_background_image'   => 'esc_url_raw',

        /* Sticky Header */
        'mobilgo_header_sticky_enable'      => 'sanitize_text_field',

        /* Logo */
        'mobilgo_site_logo'                 => 'esc_url_raw',
        'mobilgo_site_mobile_logo'          => 'esc_url_raw',
        'mobilgo_favicon_url'               => 'esc_url_raw',
        'mobilgo_inner_page_header_image'   => 'esc_url_raw',

        /* Location */
        'mobilgo_header_locations_enable'   => 'sanitize_text_field',
        'mobilgo_header_location_icon'      => 'sanitize_text_field',
        'mobilgo_header_location_title'     => 'sanitize_text_field',

        /* Legacy location fallback */
        'mobilgo_header_location_line1'     => 'sanitize_text_field',
        'mobilgo_header_location_link1'     => 'esc_url_raw',
        'mobilgo_header_location_line2'     => 'sanitize_text_field',
        'mobilgo_header_location_link2'     => 'esc_url_raw',

        /* Opening Hours */
        'mobilgo_header_hours_enable'       => 'sanitize_text_field',
        'mobilgo_header_hours_icon_class'   => 'sanitize_text_field',
        'mobilgo_header_hours_title'        => 'sanitize_text_field',
        'mobilgo_header_hours_line_1'       => 'sanitize_text_field',
        'mobilgo_header_hours_line_2'       => 'sanitize_text_field',

        /* Contact Info */
        'mobilgo_header_contact_enable'     => 'sanitize_text_field',
        'mobilgo_header_contact_icon_class' => 'sanitize_text_field',
        'mobilgo_header_contact_title'      => 'sanitize_text_field',
        'mobilgo_header_phone'              => 'sanitize_text_field',
        'mobilgo_header_email'              => 'sanitize_email',

        /* Mobile Top Header */
        'mobilgo_header_top_mobile_enable'  => 'sanitize_text_field',
    );

    foreach ( $fields as $field => $sanitize ) {
        register_setting(
            'mobilgo_header_group',
            $field,
            array(
                'type'              => 'string',
                'sanitize_callback' => $sanitize,
            )
        );
    }
}
add_action( 'admin_init', 'mobilgo_register_header_settings' );

/* =========================
   Render Header Settings Page
========================= */

function mobilgo_render_header_settings_page() {

    mobilgo_admin_settings_header(
        'Header Settings',
        'Manage header layout, logo, transparency, sticky mode and displayed header content.'
    );
    ?>

    <form method="post" action="<?php echo esc_url( admin_url( 'options.php' ) ); ?>">
        <?php settings_fields( 'mobilgo_header_group' ); ?>

        <?php mobilgo_field_section_title(
            'Header Design',
            'Choose the main header style and sticky behavior.'
        ); ?>
            <div class="mobilgo-settings-grid">
                <div class="mobilgo-settings-col">
                    <?php
                    mobilgo_field_select(
                        'Header Design',
                        'mobilgo_header_design_type',
                        array(
                            'style-1' => 'Style 1',
                            'style-2' => 'Style 2',
                            'style-3' => 'Style 3',
                        ),
                        'Select header design type.',
                        'style-1'
                    );
                    ?>
                </div>

                <div class="mobilgo-settings-col">
                    <?php
                    mobilgo_field_switch(
                        'Display Sticky Header',
                        'mobilgo_header_sticky_enable',
                        'Enable or disable sticky header.',
                        'yes'
                    );
                    ?>
                </div>
            </div>
        <?php mobilgo_field_section_close(); ?>


        <?php mobilgo_field_section_title(
            'Transparent Header',
            'Control transparent mode and fallback background styling.'
        ); ?>
            <div class="mobilgo-settings-grid">
                <div class="mobilgo-settings-col">
                    <?php
                    mobilgo_field_switch(
                        'Show Transparent Header',
                        'mobilgo_header_transparent_enable',
                        'Enable or disable transparent header.',
                        'yes'
                    );
                    ?>
                </div>

                <div class="mobilgo-settings-col">
                    <div class="mobilgo-conditional mobilgo-transparent-conditional">
                        <?php
                        mobilgo_field_select(
                            'Header Background Type',
                            'mobilgo_header_background_type',
                            array(
                                'color' => 'Color',
                                'image' => 'Image',
                            ),
                            'Choose color or image when transparent header is disabled.',
                            'color'
                        );

                        mobilgo_field_color(
                            'Header Background Color',
                            'mobilgo_header_background_color',
                            'Choose header background color.',
                            '#111111'
                        );

                        mobilgo_field_media(
                            'Header Background Image',
                            'mobilgo_header_background_image',
                            'Upload header background image.'
                        );
                        ?>
                    </div>
                </div>
            </div>
        <?php mobilgo_field_section_close(); ?>


        <?php mobilgo_field_section_title(
            'Logo',
            'Upload desktop logo, mobile logo, favicon and inner page header image.'
        ); ?>
            <div class="mobilgo-settings-grid">
                <div class="mobilgo-settings-col">
                    <?php
                    mobilgo_field_media(
                        'Site Logo',
                        'mobilgo_site_logo',
                        'Add or upload the main site logo.'
                    );

                    mobilgo_field_media(
                        'Site Mobile Logo',
                        'mobilgo_site_mobile_logo',
                        'Add or upload the mobile logo.'
                    );
                    ?>
                </div>

                <div class="mobilgo-settings-col">
                    <?php
                    mobilgo_field_media(
                        'Favicon',
                        'mobilgo_favicon_url',
                        'Upload favicon for the theme.'
                    );

                    mobilgo_field_media(
                        'Inner Page Header Image',
                        'mobilgo_inner_page_header_image',
                        'Used for inner pages only.'
                    );
                    ?>
                </div>
            </div>
        <?php mobilgo_field_section_close(); ?>


        <?php mobilgo_field_section_title(
            'Location Display',
            'Control how location information is shown in the header. Main location content now comes from General Settings → Locations.'
        ); ?>
            <div class="mobilgo-settings-grid">
                <div class="mobilgo-settings-col">
                    <?php
                    mobilgo_field_switch(
                        'Show Location',
                        'mobilgo_header_locations_enable',
                        'Enable or disable the location section in header.',
                        'yes'
                    );

                    mobilgo_field_icon_picker(
                        'Location Icon',
                        'mobilgo_header_location_icon',
                        'Choose icon for location.',
                        'fa-solid fa-location-dot'
                    );

                    mobilgo_field_text(
                        'Location Title',
                        'mobilgo_header_location_title',
                        'Find butik',
                        'Optional short title for the location block.',
                        'Find butik'
                    );
                    ?>
                </div>

                <div class="mobilgo-settings-col">
                    <?php
                    mobilgo_field_text(
                        'Legacy Location Line 1',
                        'mobilgo_header_location_line1',
                        'Frederikssund - Stenløse',
                        'Fallback only if no locations are added in General Settings.',
                        'Frederikssund - Stenløse'
                    );

                    mobilgo_field_text(
                        'Legacy Location Link 1',
                        'mobilgo_header_location_link1',
                        'https://google.com/maps',
                        'Fallback link only.',
                        ''
                    );

                    mobilgo_field_text(
                        'Legacy Location Line 2',
                        'mobilgo_header_location_line2',
                        'Farum - Amager',
                        'Fallback only if no locations are added in General Settings.',
                        'Farum - Amager'
                    );

                    mobilgo_field_text(
                        'Legacy Location Link 2',
                        'mobilgo_header_location_link2',
                        'https://google.com/maps',
                        'Fallback link only.',
                        ''
                    );
                    ?>
                </div>
            </div>
        <?php mobilgo_field_section_close(); ?>


        <?php mobilgo_field_section_title(
            'Opening Hours',
            'Manage the opening hours block shown inside the header.'
        ); ?>
            <div class="mobilgo-settings-grid">
                <div class="mobilgo-settings-col">
                    <?php
                    mobilgo_field_switch(
                        'Show Opening Hours',
                        'mobilgo_header_hours_enable',
                        'Enable or disable opening hours section.',
                        'yes'
                    );

                    mobilgo_field_icon_picker(
                        'Opening Hours Icon',
                        'mobilgo_header_hours_icon_class',
                        'Choose icon for opening hours.',
                        'fa-regular fa-clock'
                    );

                    mobilgo_field_text(
                        'Opening Hours Title',
                        'mobilgo_header_hours_title',
                        'Åbningstider',
                        'Optional short heading for the opening hours block.',
                        'Åbningstider'
                    );
                    ?>
                </div>

                <div class="mobilgo-settings-col">
                    <?php
                    mobilgo_field_text(
                        'Opening Hours Line 1',
                        'mobilgo_header_hours_line_1',
                        'Mandag - Fredag 10:00 - 18:00',
                        'First opening hours line.',
                        'Mandag - Fredag 10:00 - 18:00'
                    );

                    mobilgo_field_text(
                        'Opening Hours Line 2',
                        'mobilgo_header_hours_line_2',
                        'Lørdag - Søndag 10:00 - 14:00',
                        'Second opening hours line.',
                        'Lørdag - Søndag 10:00 - 14:00'
                    );
                    ?>
                </div>
            </div>
        <?php mobilgo_field_section_close(); ?>


        <?php mobilgo_field_section_title(
            'Contact Info',
            'Manage the contact information block shown inside the header. If Business Info is filled in General Settings, it will be used as primary source.'
        ); ?>
            <div class="mobilgo-settings-grid">
                <div class="mobilgo-settings-col">
                    <?php
                    mobilgo_field_switch(
                        'Show Contact Info',
                        'mobilgo_header_contact_enable',
                        'Enable or disable contact info section.',
                        'yes'
                    );

                    mobilgo_field_icon_picker(
                        'Contact Icon',
                        'mobilgo_header_contact_icon_class',
                        'Choose icon for contact info.',
                        'fa-solid fa-phone'
                    );

                    mobilgo_field_text(
                        'Contact Title',
                        'mobilgo_header_contact_title',
                        'Kontakt os',
                        'Optional short heading for the contact block.',
                        'Kontakt os'
                    );
                    ?>
                </div>

                <div class="mobilgo-settings-col">
                    <?php
                    mobilgo_field_text(
                        'Header Phone Fallback',
                        'mobilgo_header_phone',
                        '+45 22 66 66 69',
                        'Used only if main company phone is empty in General Settings.',
                        '+45 22 66 66 69'
                    );

                    mobilgo_field_text(
                        'Header Email Fallback',
                        'mobilgo_header_email',
                        'info@mobilgo.dk',
                        'Used only if main company email is empty in General Settings.',
                        'info@mobilgo.dk'
                    );
                    ?>
                </div>
            </div>
        <?php mobilgo_field_section_close(); ?>


        <?php mobilgo_field_section_title(
            'Mobile Top Header',
            'Control extra header content for mobile devices.'
        ); ?>
            <div class="mobilgo-settings-grid">
                <div class="mobilgo-settings-col">
                    <?php
                    mobilgo_field_switch(
                        'Display Header Top Mobile',
                        'mobilgo_header_top_mobile_enable',
                        'Enable or disable mobile header top content.',
                        'yes'
                    );
                    ?>
                </div>

                <div class="mobilgo-settings-col"></div>
            </div>
        <?php mobilgo_field_section_close(); ?>

        <?php mobilgo_admin_settings_actions(); ?>
    </form>

    <?php
    mobilgo_admin_settings_footer();
}
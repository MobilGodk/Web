<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MobilGo_Repair_Brands_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mobilgo_repair_brands';
    }

    public function get_title() {
        return 'MobilGo Repair Brands';
    }

    public function get_icon() {
        return 'eicon-gallery-grid';
    }

    public function get_categories() {
        return array( 'mobilgo' );
    }

    public function get_keywords() {
        return array( 'mobilgo', 'brands', 'repair', 'devices', 'grid' );
    }

    protected function register_controls() {

        /* =========================
           Section Content
        ========================= */

        $this->start_controls_section(
            'section_content',
            array(
                'label' => 'Content Settings',
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'section_title',
            array(
                'label'   => 'Section Title',
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => 'Reparation af populære enheder',
            )
        );

        $this->add_control(
            'section_text',
            array(
                'label'   => 'Section Text',
                'type'    => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'Vi reparerer de mest populære smartphones, tablets og computere hurtigt og professionelt.',
            )
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'item_label',
            array(
                'label'   => 'Item Label',
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => 'Brand 1',
            )
        );

        $repeater->add_control(
            'item_title',
            array(
                'label'   => 'Item Title',
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => 'iPhone',
            )
        );

        $repeater->add_control(
            'item_image',
            array(
                'label'   => 'Image',
                'type'    => \Elementor\Controls_Manager::MEDIA,
                'default' => array(
                    'url' => '',
                ),
            )
        );

        $repeater->add_control(
            'item_link',
            array(
                'label'         => 'Link',
                'type'          => \Elementor\Controls_Manager::URL,
                'show_external' => true,
                'default'       => array(
                    'url' => '#',
                ),
            )
        );

        $this->add_control(
            'brand_items',
            array(
                'label'       => 'Brands / Devices',
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ item_label }}}',
                'button_text' => 'Add Item',
                'default'     => array(
                    array(
                        'item_label' => 'Item 1',
                        'item_title' => 'iPhone',
                    ),
                    array(
                        'item_label' => 'Item 2',
                        'item_title' => 'Samsung',
                    ),
                    array(
                        'item_label' => 'Item 3',
                        'item_title' => 'iPad',
                    ),
                    array(
                        'item_label' => 'Item 4',
                        'item_title' => 'MacBook',
                    ),
                ),
            )
        );

        $this->end_controls_section();

        /* =========================
           Grid Settings
        ========================= */

        $this->start_controls_section(
            'grid_settings_section',
            array(
                'label' => 'Grid Settings',
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'columns_desktop',
            array(
                'label'   => 'Columns Desktop',
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => '4',
                'options' => array(
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                    '6' => '6',
                ),
            )
        );

        $this->add_control(
            'columns_tablet',
            array(
                'label'   => 'Columns Tablet',
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => '3',
                'options' => array(
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ),
            )
        );

        $this->add_control(
            'columns_mobile',
            array(
                'label'   => 'Columns Mobile',
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => '2',
                'options' => array(
                    '1' => '1',
                    '2' => '2',
                ),
            )
        );

        $this->end_controls_section();

        /* =========================
           Section Design
        ========================= */

        $this->start_controls_section(
            'section_design',
            array(
                'label' => 'Section Design',
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'section_bg',
            array(
                'label' => 'Section Background',
                'type'  => \Elementor\Controls_Manager::COLOR,
            )
        );

        $this->add_control(
            'title_color',
            array(
                'label' => 'Title Color',
                'type'  => \Elementor\Controls_Manager::COLOR,
            )
        );

        $this->add_control(
            'text_color',
            array(
                'label' => 'Text Color',
                'type'  => \Elementor\Controls_Manager::COLOR,
            )
        );

        $this->end_controls_section();

        /* =========================
           Item Design
        ========================= */

        $this->start_controls_section(
            'item_design',
            array(
                'label' => 'Item Design',
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'item_bg',
            array(
                'label' => 'Item Background',
                'type'  => \Elementor\Controls_Manager::COLOR,
            )
        );

        $this->add_control(
            'item_title_color',
            array(
                'label' => 'Item Title Color',
                'type'  => \Elementor\Controls_Manager::COLOR,
            )
        );

        $this->add_control(
            'item_hover_bg',
            array(
                'label' => 'Item Hover Background',
                'type'  => \Elementor\Controls_Manager::COLOR,
            )
        );

        $this->add_control(
            'item_hover_title_color',
            array(
                'label' => 'Item Hover Title Color',
                'type'  => \Elementor\Controls_Manager::COLOR,
            )
        );

        $this->end_controls_section();
    }

    protected function get_link_attrs( $link = array() ) {
        $link  = is_array( $link ) ? $link : array();
        $attrs = array();

        if ( ! empty( $link['url'] ) ) {
            $attrs[] = 'href="' . esc_url( $link['url'] ) . '"';
        } else {
            $attrs[] = 'href="#"';
        }

        if ( ! empty( $link['is_external'] ) ) {
            $attrs[] = 'target="_blank"';
            $attrs[] = 'rel="noopener"';
        }

        if ( ! empty( $link['nofollow'] ) ) {
            $attrs[] = 'rel="nofollow"';
        }

        return implode( ' ', $attrs );
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $items    = ! empty( $settings['brand_items'] ) ? $settings['brand_items'] : array();

        if ( empty( $items ) ) {
            return;
        }

        $section_styles = array(
            '--mobilgo-brands-section-bg:' . ( ! empty( $settings['section_bg'] ) ? $settings['section_bg'] : '#ffffff' ),
            '--mobilgo-brands-title-color:' . ( ! empty( $settings['title_color'] ) ? $settings['title_color'] : '#111111' ),
            '--mobilgo-brands-text-color:' . ( ! empty( $settings['text_color'] ) ? $settings['text_color'] : '#555555' ),
            '--mobilgo-brands-item-bg:' . ( ! empty( $settings['item_bg'] ) ? $settings['item_bg'] : '#ffffff' ),
            '--mobilgo-brands-item-title:' . ( ! empty( $settings['item_title_color'] ) ? $settings['item_title_color'] : '#222222' ),
            '--mobilgo-brands-item-hover-bg:' . ( ! empty( $settings['item_hover_bg'] ) ? $settings['item_hover_bg'] : '#d10000' ),
            '--mobilgo-brands-item-hover-title:' . ( ! empty( $settings['item_hover_title_color'] ) ? $settings['item_hover_title_color'] : '#ffffff' ),
            '--mobilgo-brands-columns-desktop:' . ( ! empty( $settings['columns_desktop'] ) ? $settings['columns_desktop'] : '4' ),
            '--mobilgo-brands-columns-tablet:' . ( ! empty( $settings['columns_tablet'] ) ? $settings['columns_tablet'] : '3' ),
            '--mobilgo-brands-columns-mobile:' . ( ! empty( $settings['columns_mobile'] ) ? $settings['columns_mobile'] : '2' ),
        );
        ?>
        <section class="mobilgo-repair-brands" style="<?php echo esc_attr( implode( ';', $section_styles ) ); ?>">
            <div class="mobilgo-repair-brands__container">

                <?php if ( ! empty( $settings['section_title'] ) ) : ?>
                    <h2 class="mobilgo-repair-brands__title"><?php echo esc_html( $settings['section_title'] ); ?></h2>
                <?php endif; ?>

                <?php if ( ! empty( $settings['section_text'] ) ) : ?>
                    <p class="mobilgo-repair-brands__text"><?php echo esc_html( $settings['section_text'] ); ?></p>
                <?php endif; ?>

                <div class="mobilgo-repair-brands__grid">
                    <?php foreach ( $items as $item ) : ?>
                        <?php $link_attrs = $this->get_link_attrs( isset( $item['item_link'] ) ? $item['item_link'] : array() ); ?>
                        <a class="mobilgo-repair-brands__item" <?php echo $link_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
                            <div class="mobilgo-repair-brands__image-wrap">
                                <?php if ( ! empty( $item['item_image']['url'] ) ) : ?>
                                    <img
                                        class="mobilgo-repair-brands__image"
                                        src="<?php echo esc_url( $item['item_image']['url'] ); ?>"
                                        alt="<?php echo esc_attr( ! empty( $item['item_title'] ) ? $item['item_title'] : 'Brand' ); ?>"
                                    >
                                <?php endif; ?>
                            </div>

                            <?php if ( ! empty( $item['item_title'] ) ) : ?>
                                <span class="mobilgo-repair-brands__item-title"><?php echo esc_html( $item['item_title'] ); ?></span>
                            <?php endif; ?>
                        </a>
                    <?php endforeach; ?>
                </div>

            </div>
        </section>
        <?php
    }
}
<?php
/**
 * MobilGo Hero Widget v4.0
 * Per-slide design controls + fixed button hover + fixed bottom line toggle.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MobilGo_Hero_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mobilgo_hero';
    }

    public function get_title() {
        return 'MobilGo Hero';
    }

    public function get_icon() {
        return 'eicon-slides';
    }

    public function get_categories() {
        return array( 'mobilgo' );
    }

    public function get_keywords() {
        return array( 'mobilgo', 'hero', 'slider', 'banner', 'boxes' );
    }

    protected function register_controls() {

        /* =========================
           Content Settings
        ========================= */

        $this->start_controls_section(
            'content_settings_section',
            array(
                'label' => 'Content Settings',
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );

        $slide_repeater = new \Elementor\Repeater();

        /* ---------- Basic Slide Content ---------- */

        $slide_repeater->add_control(
            'slide_label',
            array(
                'label'   => 'Slide Label',
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => 'Slide 1',
            )
        );

        $slide_repeater->add_control(
            'background_type',
            array(
                'label'   => 'Background Type',
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'image',
                'options' => array(
                    'image' => 'Image',
                    'video' => 'Video',
                ),
            )
        );

        $slide_repeater->add_control(
            'background_image',
            array(
                'label'     => 'Image',
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => array(
                    'url' => '',
                ),
                'condition' => array(
                    'background_type' => 'image',
                ),
            )
        );

        $slide_repeater->add_control(
            'background_video',
            array(
                'label'       => 'Video URL',
                'type'        => \Elementor\Controls_Manager::TEXT,
                'placeholder' => 'https://example.com/video.mp4',
                'condition'   => array(
                    'background_type' => 'video',
                ),
            )
        );

        $slide_repeater->add_control(
            'heading',
            array(
                'label'   => 'Heading',
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => 'Your Smartphone Matters',
            )
        );

        $slide_repeater->add_control(
            'subheading',
            array(
                'label'   => 'Sub Heading',
                'type'    => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'Reparation af smartphones, tablets og computere – hurtigt og professionelt.',
            )
        );

        $slide_repeater->add_control(
            'button_1_text',
            array(
                'label'   => 'Button 1 Title',
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => 'Bestil reparation',
            )
        );

        $slide_repeater->add_control(
            'button_1_link',
            array(
                'label'         => 'Button 1 Link',
                'type'          => \Elementor\Controls_Manager::URL,
                'show_external' => true,
                'default'       => array(
                    'url' => '#',
                ),
            )
        );

        $slide_repeater->add_control(
            'enable_button_2',
            array(
                'label'        => 'Enable Button 2',
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => 'Yes',
                'label_off'    => 'No',
                'return_value' => 'yes',
                'default'      => '',
            )
        );

        $slide_repeater->add_control(
            'button_2_text',
            array(
                'label'     => 'Button 2 Title',
                'type'      => \Elementor\Controls_Manager::TEXT,
                'default'   => '',
                'condition' => array(
                    'enable_button_2' => 'yes',
                ),
            )
        );

        $slide_repeater->add_control(
            'button_2_link',
            array(
                'label'         => 'Button 2 Link',
                'type'          => \Elementor\Controls_Manager::URL,
                'show_external' => true,
                'default'       => array(
                    'url' => '#',
                ),
                'condition'     => array(
                    'enable_button_2' => 'yes',
                ),
            )
        );

        /* ---------- Per Slide Design ---------- */

        $slide_repeater->add_control(
            'slide_design_heading',
            array(
                'type'            => \Elementor\Controls_Manager::RAW_HTML,
                'raw'             => '<hr><strong>Slide Design</strong>',
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
            )
        );

        $slide_repeater->add_control(
            'content_align',
            array(
                'label'   => 'Content Align',
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => '',
                'options' => array(
                    ''       => 'Theme Default',
                    'left'   => 'Left',
                    'center' => 'Center',
                    'right'  => 'Right',
                ),
            )
        );

        $slide_repeater->add_control(
            'content_max_width',
            array(
                'label'      => 'Content Max Width',
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => array( 'px' ),
                'range'      => array(
                    'px' => array(
                        'min' => 400,
                        'max' => 1400,
                    ),
                ),
            )
        );

        $slide_repeater->add_control(
            'heading_color',
            array(
                'label' => 'Heading Color',
                'type'  => \Elementor\Controls_Manager::COLOR,
            )
        );

        $slide_repeater->add_control(
            'heading_size',
            array(
                'label'      => 'Heading Size',
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => array( 'px' ),
                'range'      => array(
                    'px' => array(
                        'min' => 20,
                        'max' => 120,
                    ),
                ),
            )
        );

        $slide_repeater->add_control(
            'subheading_color',
            array(
                'label' => 'Sub Heading Color',
                'type'  => \Elementor\Controls_Manager::COLOR,
            )
        );

        $slide_repeater->add_control(
            'subheading_size',
            array(
                'label'      => 'Sub Heading Size',
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => array( 'px' ),
                'range'      => array(
                    'px' => array(
                        'min' => 12,
                        'max' => 50,
                    ),
                ),
            )
        );

        /* ---------- Button 1 Design ---------- */

        $slide_repeater->add_control(
            'button_1_design_heading',
            array(
                'type'            => \Elementor\Controls_Manager::RAW_HTML,
                'raw'             => '<strong>Button 1 Design</strong>',
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
            )
        );

        $slide_repeater->add_control(
            'button_1_style',
            array(
                'label'   => 'Button 1 Style',
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => '',
                'options' => array(
                    ''        => 'Theme Default',
                    'solid'   => 'Solid',
                    'outline' => 'Outline',
                    'ghost'   => 'Ghost',
                ),
            )
        );

        $slide_repeater->add_control(
            'button_1_bg_color',
            array(
                'label' => 'Button 1 Background',
                'type'  => \Elementor\Controls_Manager::COLOR,
            )
        );

        $slide_repeater->add_control(
            'button_1_text_color',
            array(
                'label' => 'Button 1 Text Color',
                'type'  => \Elementor\Controls_Manager::COLOR,
            )
        );

        $slide_repeater->add_control(
            'button_1_hover_bg_color',
            array(
                'label' => 'Button 1 Hover Background',
                'type'  => \Elementor\Controls_Manager::COLOR,
            )
        );

        $slide_repeater->add_control(
            'button_1_hover_text_color',
            array(
                'label' => 'Button 1 Hover Text Color',
                'type'  => \Elementor\Controls_Manager::COLOR,
            )
        );

        /* ---------- Button 2 Design ---------- */

        $slide_repeater->add_control(
            'button_2_design_heading',
            array(
                'type'            => \Elementor\Controls_Manager::RAW_HTML,
                'raw'             => '<strong>Button 2 Design</strong>',
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
                'condition'       => array(
                    'enable_button_2' => 'yes',
                ),
            )
        );

        $slide_repeater->add_control(
            'button_2_style',
            array(
                'label'     => 'Button 2 Style',
                'type'      => \Elementor\Controls_Manager::SELECT,
                'default'   => '',
                'options'   => array(
                    ''        => 'Theme Default',
                    'solid'   => 'Solid',
                    'outline' => 'Outline',
                    'ghost'   => 'Ghost',
                ),
                'condition' => array(
                    'enable_button_2' => 'yes',
                ),
            )
        );

        $slide_repeater->add_control(
            'button_2_bg_color',
            array(
                'label'     => 'Button 2 Background',
                'type'      => \Elementor\Controls_Manager::COLOR,
                'condition' => array(
                    'enable_button_2' => 'yes',
                ),
            )
        );

        $slide_repeater->add_control(
            'button_2_text_color',
            array(
                'label'     => 'Button 2 Text Color',
                'type'      => \Elementor\Controls_Manager::COLOR,
                'condition' => array(
                    'enable_button_2' => 'yes',
                ),
            )
        );

        $slide_repeater->add_control(
            'button_2_hover_bg_color',
            array(
                'label'     => 'Button 2 Hover Background',
                'type'      => \Elementor\Controls_Manager::COLOR,
                'condition' => array(
                    'enable_button_2' => 'yes',
                ),
            )
        );

        $slide_repeater->add_control(
            'button_2_hover_text_color',
            array(
                'label'     => 'Button 2 Hover Text Color',
                'type'      => \Elementor\Controls_Manager::COLOR,
                'condition' => array(
                    'enable_button_2' => 'yes',
                ),
            )
        );

        $this->add_control(
            'slides',
            array(
                'label'       => 'Slides',
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $slide_repeater->get_controls(),
                'title_field' => '{{{ slide_label }}}',
                'button_text' => 'Add Slide',
                'default'     => array(
                    array(
                        'slide_label'     => 'Slide 1',
                        'background_type' => 'image',
                        'heading'         => 'Your Smartphone Matters',
                        'subheading'      => 'Reparation af smartphones, tablets og computere – hurtigt og professionelt.',
                        'button_1_text'   => 'Bestil reparation',
                        'enable_button_2' => '',
                    ),
                ),
            )
        );

        $this->end_controls_section();

        /* =========================
           Slider Settings
        ========================= */

        $this->start_controls_section(
            'slider_settings_section',
            array(
                'label' => 'Slider Settings',
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'autoplay_slides',
            array(
                'label'        => 'Autoplay Slides',
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => 'Yes',
                'label_off'    => 'No',
                'return_value' => 'yes',
                'default'      => '',
            )
        );

        $this->add_control(
            'autoplay_speed',
            array(
                'label'     => 'Autoplay Speed',
                'type'      => \Elementor\Controls_Manager::NUMBER,
                'default'   => 5000,
                'condition' => array(
                    'autoplay_slides' => 'yes',
                ),
            )
        );

        $this->add_control(
            'enable_arrows',
            array(
                'label'        => 'Enable Arrows',
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => 'Yes',
                'label_off'    => 'No',
                'return_value' => 'yes',
                'default'      => '',
            )
        );

        $this->add_control(
            'overlay_opacity',
            array(
                'label'      => 'Overlay Opacity',
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => array( '%' ),
                'range'      => array(
                    '%' => array(
                        'min' => 0,
                        'max' => 100,
                    ),
                ),
                'default' => array(
                    'unit' => '%',
                    'size' => 45,
                ),
            )
        );

        $this->add_control(
            'hero_height',
            array(
                'label'   => 'Hero Height',
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => '90vh',
                'options' => array(
                    '80vh'  => '80vh',
                    '90vh'  => '90vh',
                    '100vh' => '100vh',
                    '750px' => '750px',
                ),
            )
        );

        $this->end_controls_section();

        /* =========================
           Hero Boxes
        ========================= */

        $this->start_controls_section(
            'hero_boxes_section',
            array(
                'label' => 'Hero Boxes',
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'enable_hero_boxes',
            array(
                'label'        => 'Enable Hero Boxes',
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => 'Yes',
                'label_off'    => 'No',
                'return_value' => 'yes',
                'default'      => 'yes',
            )
        );

        $box_repeater = new \Elementor\Repeater();

        $box_repeater->add_control(
            'box_label',
            array(
                'label'   => 'Box Label',
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => 'Item 1',
            )
        );

        $box_repeater->add_control(
            'tab_title',
            array(
                'label'   => 'Tab Title',
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => 'Reparation',
            )
        );

        $box_repeater->add_control(
            'box_icon',
            array(
                'label' => 'Icon',
                'type'  => \Elementor\Controls_Manager::ICONS,
            )
        );

        $box_repeater->add_control(
            'section_id',
            array(
                'label'       => 'Section Id',
                'type'        => \Elementor\Controls_Manager::TEXT,
                'placeholder' => 'repair-section',
            )
        );

        $box_repeater->add_control(
            'box_link',
            array(
                'label'         => 'Link',
                'type'          => \Elementor\Controls_Manager::URL,
                'show_external' => true,
                'default'       => array(
                    'url' => '#',
                ),
            )
        );

        $this->add_control(
            'hero_boxes',
            array(
                'label'       => 'Boxes',
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $box_repeater->get_controls(),
                'title_field' => '{{{ box_label }}}',
                'button_text' => 'Add Box',
                'condition'   => array(
                    'enable_hero_boxes' => 'yes',
                ),
                'default'     => array(
                    array(
                        'box_label' => 'Item 1',
                        'tab_title' => 'Reparation',
                    ),
                    array(
                        'box_label' => 'Item 2',
                        'tab_title' => 'Find butik',
                    ),
                    array(
                        'box_label' => 'Item 3',
                        'tab_title' => 'Sælg din enhed',
                    ),
                ),
            )
        );

        $this->end_controls_section();

        /* =========================
           Hero Design
        ========================= */

        $this->start_controls_section(
            'hero_design_section',
            array(
                'label' => 'Hero Design',
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'box_bg_color',
            array(
                'label' => 'Box Background Color',
                'type'  => \Elementor\Controls_Manager::COLOR,
            )
        );

        $this->add_control(
            'box_text_color',
            array(
                'label' => 'Box Text Color',
                'type'  => \Elementor\Controls_Manager::COLOR,
            )
        );

        $this->add_control(
            'box_icon_color',
            array(
                'label' => 'Box Icon Color',
                'type'  => \Elementor\Controls_Manager::COLOR,
            )
        );

        $this->add_control(
            'box_hover_bg_color',
            array(
                'label' => 'Box Hover Background Color',
                'type'  => \Elementor\Controls_Manager::COLOR,
            )
        );

        $this->add_control(
            'box_hover_text_color',
            array(
                'label' => 'Box Hover Text Color',
                'type'  => \Elementor\Controls_Manager::COLOR,
            )
        );

        $this->add_control(
            'box_hover_icon_color',
            array(
                'label' => 'Box Hover Icon Color',
                'type'  => \Elementor\Controls_Manager::COLOR,
            )
        );

        $this->add_control(
            'box_show_bottom_line',
            array(
                'label'        => 'Show Bottom Line',
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => 'Yes',
                'label_off'    => 'No',
                'return_value' => 'yes',
                'default'      => 'yes',
            )
        );

        $this->add_control(
            'box_bottom_line_color',
            array(
                'label' => 'Bottom Line Color',
                'type'  => \Elementor\Controls_Manager::COLOR,
            )
        );

        $this->end_controls_section();
    }

    /* =========================
       Helpers
    ========================= */

    protected function get_theme_option_value( $option_name, $default = '' ) {
        $value = get_option( $option_name, '' );
        return '' !== $value ? $value : $default;
    }

    protected function get_control_or_theme_value( $widget_value, $theme_option, $default = '' ) {
        if ( '' !== $widget_value && null !== $widget_value ) {
            return $widget_value;
        }

        $theme_value = $this->get_theme_option_value( $theme_option, '' );
        if ( '' !== $theme_value && null !== $theme_value ) {
            return $theme_value;
        }

        return $default;
    }

    protected function get_control_size_or_theme_value( $control_value, $theme_option, $default = '' ) {
        if ( isset( $control_value['size'] ) && '' !== $control_value['size'] && null !== $control_value['size'] ) {
            return $control_value['size'] . ( ! empty( $control_value['unit'] ) ? $control_value['unit'] : 'px' );
        }

        $theme_value = $this->get_theme_option_value( $theme_option, '' );
        if ( '' !== $theme_value ) {
            return $theme_value;
        }

        return $default;
    }

    protected function get_link_attrs( $link = array(), $allow_external = true ) {
        $link  = is_array( $link ) ? $link : array();
        $attrs = array();

        if ( ! empty( $link['url'] ) ) {
            $attrs[] = 'href="' . esc_url( $link['url'] ) . '"';
        } else {
            $attrs[] = 'href="#"';
        }

        $rels = array();

        if ( $allow_external && ! empty( $link['is_external'] ) ) {
            $attrs[] = 'target="_blank"';
            $rels[]  = 'noopener';
        }

        if ( ! empty( $link['nofollow'] ) ) {
            $rels[] = 'nofollow';
        }

        if ( ! empty( $rels ) ) {
            $attrs[] = 'rel="' . esc_attr( implode( ' ', array_unique( $rels ) ) ) . '"';
        }

        return implode( ' ', $attrs );
    }

    protected function get_slide_style_data( $slide = array() ) {
        $heading_color       = $this->get_control_or_theme_value( isset( $slide['heading_color'] ) ? $slide['heading_color'] : '', 'mobilgo_hero_heading_color', '#ffffff' );
        $heading_size        = $this->get_control_size_or_theme_value( isset( $slide['heading_size'] ) ? $slide['heading_size'] : array(), 'mobilgo_hero_heading_size', '64px' );
        $subheading_color    = $this->get_control_or_theme_value( isset( $slide['subheading_color'] ) ? $slide['subheading_color'] : '', 'mobilgo_hero_subheading_color', 'rgba(255,255,255,0.92)' );
        $subheading_size     = $this->get_control_size_or_theme_value( isset( $slide['subheading_size'] ) ? $slide['subheading_size'] : array(), 'mobilgo_hero_subheading_size', '18px' );
        $content_max_width   = $this->get_control_size_or_theme_value( isset( $slide['content_max_width'] ) ? $slide['content_max_width'] : array(), 'mobilgo_hero_content_max_width', '900px' );
        $content_align       = $this->get_control_or_theme_value( isset( $slide['content_align'] ) ? $slide['content_align'] : '', 'mobilgo_hero_content_align', 'center' );

        $button_1_style      = $this->get_control_or_theme_value( isset( $slide['button_1_style'] ) ? $slide['button_1_style'] : '', 'mobilgo_hero_button_1_style', 'solid' );
        $button_1_bg         = $this->get_control_or_theme_value( isset( $slide['button_1_bg_color'] ) ? $slide['button_1_bg_color'] : '', 'mobilgo_hero_button_1_bg_color', '#d10000' );
        $button_1_text       = $this->get_control_or_theme_value( isset( $slide['button_1_text_color'] ) ? $slide['button_1_text_color'] : '', 'mobilgo_hero_button_1_text_color', '#ffffff' );
        $button_1_hover_bg   = $this->get_control_or_theme_value( isset( $slide['button_1_hover_bg_color'] ) ? $slide['button_1_hover_bg_color'] : '', 'mobilgo_hero_button_1_hover_bg_color', '#a80000' );
        $button_1_hover_text = $this->get_control_or_theme_value( isset( $slide['button_1_hover_text_color'] ) ? $slide['button_1_hover_text_color'] : '', 'mobilgo_hero_button_1_hover_text_color', '#ffffff' );

        $button_2_style      = $this->get_control_or_theme_value( isset( $slide['button_2_style'] ) ? $slide['button_2_style'] : '', 'mobilgo_hero_button_2_style', 'outline' );
        $button_2_bg         = $this->get_control_or_theme_value( isset( $slide['button_2_bg_color'] ) ? $slide['button_2_bg_color'] : '', 'mobilgo_hero_button_2_bg_color', 'transparent' );
        $button_2_text       = $this->get_control_or_theme_value( isset( $slide['button_2_text_color'] ) ? $slide['button_2_text_color'] : '', 'mobilgo_hero_button_2_text_color', '#ffffff' );
        $button_2_hover_bg   = $this->get_control_or_theme_value( isset( $slide['button_2_hover_bg_color'] ) ? $slide['button_2_hover_bg_color'] : '', 'mobilgo_hero_button_2_hover_bg_color', '#ffffff' );
        $button_2_hover_text = $this->get_control_or_theme_value( isset( $slide['button_2_hover_text_color'] ) ? $slide['button_2_hover_text_color'] : '', 'mobilgo_hero_button_2_hover_text_color', '#000000' );

        $styles = array(
            '--mobilgo-heading-color:' . esc_attr( $heading_color ),
            '--mobilgo-heading-size:' . esc_attr( $heading_size ),
            '--mobilgo-subheading-color:' . esc_attr( $subheading_color ),
            '--mobilgo-subheading-size:' . esc_attr( $subheading_size ),
            '--mobilgo-content-max-width:' . esc_attr( $content_max_width ),
            '--mobilgo-button-1-bg:' . esc_attr( $button_1_bg ),
            '--mobilgo-button-1-text:' . esc_attr( $button_1_text ),
            '--mobilgo-button-1-hover-bg:' . esc_attr( $button_1_hover_bg ),
            '--mobilgo-button-1-hover-text:' . esc_attr( $button_1_hover_text ),
            '--mobilgo-button-2-bg:' . esc_attr( $button_2_bg ),
            '--mobilgo-button-2-text:' . esc_attr( $button_2_text ),
            '--mobilgo-button-2-hover-bg:' . esc_attr( $button_2_hover_bg ),
            '--mobilgo-button-2-hover-text:' . esc_attr( $button_2_hover_text ),
        );

        return array(
            'style'          => implode( ';', $styles ),
            'content_align'  => $content_align,
            'button_1_style' => $button_1_style,
            'button_2_style' => $button_2_style,
        );
    }
    
    protected function get_hero_box_design_vars( $settings = array() ) {
    $bg_color         = $this->get_control_or_theme_value( isset( $settings['box_bg_color'] ) ? $settings['box_bg_color'] : '', 'mobilgo_hero_box_bg_color', '#ffffff' );
    $text_color       = $this->get_control_or_theme_value( isset( $settings['box_text_color'] ) ? $settings['box_text_color'] : '', 'mobilgo_hero_box_text_color', '#222222' );
    $icon_color       = $this->get_control_or_theme_value( isset( $settings['box_icon_color'] ) ? $settings['box_icon_color'] : '', 'mobilgo_hero_box_icon_color', '#d10000' );
    $hover_bg_color   = $this->get_control_or_theme_value( isset( $settings['box_hover_bg_color'] ) ? $settings['box_hover_bg_color'] : '', 'mobilgo_hero_box_hover_bg_color', '#d10000' );
    $hover_text_color = $this->get_control_or_theme_value( isset( $settings['box_hover_text_color'] ) ? $settings['box_hover_text_color'] : '', 'mobilgo_hero_box_hover_text_color', '#ffffff' );
    $hover_icon_color = $this->get_control_or_theme_value( isset( $settings['box_hover_icon_color'] ) ? $settings['box_hover_icon_color'] : '', 'mobilgo_hero_box_hover_icon_color', '#ffffff' );

    /* هذا هو الإصلاح */
    if ( isset( $settings['box_show_bottom_line'] ) ) {
        $show_line_raw = ( 'yes' === $settings['box_show_bottom_line'] ) ? 'yes' : 'no';
    } else {
        $show_line_raw = $this->get_theme_option_value( 'mobilgo_hero_box_show_bottom_line', 'yes' );
    }

    $line_color = $this->get_control_or_theme_value(
        isset( $settings['box_bottom_line_color'] ) ? $settings['box_bottom_line_color'] : '',
        'mobilgo_hero_box_bottom_line_color',
        '#d10000'
    );

    $line_height = ( 'yes' === $show_line_raw ) ? '3px' : '0px';
    $line_final_color = ( 'yes' === $show_line_raw ) ? $line_color : 'transparent';

    $styles = array(
        '--mobilgo-box-bg:' . esc_attr( $bg_color ),
        '--mobilgo-box-text:' . esc_attr( $text_color ),
        '--mobilgo-box-icon:' . esc_attr( $icon_color ),
        '--mobilgo-box-hover-bg:' . esc_attr( $hover_bg_color ),
        '--mobilgo-box-hover-text:' . esc_attr( $hover_text_color ),
        '--mobilgo-box-hover-icon:' . esc_attr( $hover_icon_color ),
        '--mobilgo-box-line-height:' . esc_attr( $line_height ),
        '--mobilgo-box-line-color:' . esc_attr( $line_final_color ),
    );

    return implode( ';', $styles );
    
    }

    protected function render_button( $text, $link, $class_name = 'primary', $style_variant = 'solid' ) {
        if ( empty( $text ) ) {
            return;
        }

        $link_attrs = $this->get_link_attrs( $link );

        echo '<a class="mg-btn mg-btn--' . esc_attr( $class_name ) . ' mg-btn--style-' . esc_attr( $style_variant ) . '" ' . $link_attrs . '>';
        echo esc_html( $text );
        echo '</a>';
    }

    protected function render_boxes( $boxes = array(), $box_design_vars = '' ) {
        if ( empty( $boxes ) ) {
            return;
        }
        ?>
        <div class="mobilgo-hero-boxes">
            <div class="container">
                <div class="mobilgo-hero-boxes__grid">
                    <?php foreach ( $boxes as $box ) : ?>
                        <?php
                        $section_id        = ! empty( $box['section_id'] ) ? '#' . ltrim( $box['section_id'], '#' ) : '';
                        $has_custom_anchor = ! empty( $section_id );

                        if ( $has_custom_anchor ) {
                            $link_attrs = 'href="' . esc_attr( $section_id ) . '"';
                        } else {
                            $box_link   = isset( $box['box_link'] ) && is_array( $box['box_link'] ) ? $box['box_link'] : array();
                            $link_attrs = $this->get_link_attrs( $box_link );
                        }
                        ?>
                        <a class="mobilgo-hero-box" style="<?php echo esc_attr( $box_design_vars ); ?>" <?php echo $link_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
                            <?php if ( ! empty( $box['box_icon'] ) ) : ?>
                                <span class="mobilgo-hero-box__icon">
                                    <?php \Elementor\Icons_Manager::render_icon( $box['box_icon'], array( 'aria-hidden' => 'true' ) ); ?>
                                </span>
                            <?php endif; ?>

                            <?php if ( ! empty( $box['tab_title'] ) ) : ?>
                                <span class="mobilgo-hero-box__title"><?php echo esc_html( $box['tab_title'] ); ?></span>
                            <?php endif; ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $slides   = ! empty( $settings['slides'] ) ? $settings['slides'] : array();
        $boxes    = ( ! empty( $settings['enable_hero_boxes'] ) && 'yes' === $settings['enable_hero_boxes'] && ! empty( $settings['hero_boxes'] ) ) ? $settings['hero_boxes'] : array();

        if ( empty( $slides ) ) {
            return;
        }

        $hero_height     = ! empty( $settings['hero_height'] ) ? $settings['hero_height'] : '90vh';
        $overlay_size    = isset( $settings['overlay_opacity']['size'] ) ? (int) $settings['overlay_opacity']['size'] : 45;
        $overlay_size    = max( 0, min( 100, $overlay_size ) );
        $overlay_opacity = $overlay_size / 100;

        $autoplay       = ( ! empty( $settings['autoplay_slides'] ) && 'yes' === $settings['autoplay_slides'] ) ? 'true' : 'false';
        $autoplay_speed = ! empty( $settings['autoplay_speed'] ) ? (int) $settings['autoplay_speed'] : 5000;
        $enable_arrows  = ( ! empty( $settings['enable_arrows'] ) && 'yes' === $settings['enable_arrows'] ) ? 'yes' : 'no';
        $slider_id      = 'mobilgo-hero-slider-' . $this->get_id();

        $box_design_vars = $this->get_hero_box_design_vars( $settings );
        ?>

        <div class="mobilgo-hero-wrap">
            <div
                id="<?php echo esc_attr( $slider_id ); ?>"
                class="mobilgo-hero-slider"
                data-autoplay="<?php echo esc_attr( $autoplay ); ?>"
                data-speed="<?php echo esc_attr( $autoplay_speed ); ?>"
                data-arrows="<?php echo esc_attr( $enable_arrows ); ?>"
                style="--mobilgo-hero-height: <?php echo esc_attr( $hero_height ); ?>; --mobilgo-overlay-opacity: <?php echo esc_attr( $overlay_opacity ); ?>;"
            >
                <?php foreach ( $slides as $index => $slide ) : ?>
                    <?php
                    $active_class = ( 0 === $index ) ? ' is-active' : '';
                    $bg_type      = ! empty( $slide['background_type'] ) ? $slide['background_type'] : 'image';
                    $bg_image     = ! empty( $slide['background_image']['url'] ) ? $slide['background_image']['url'] : '';
                    $bg_video     = ! empty( $slide['background_video'] ) ? $slide['background_video'] : '';
                    $button_2_on  = ! empty( $slide['enable_button_2'] ) && 'yes' === $slide['enable_button_2'];

                    $slide_style_data = $this->get_slide_style_data( $slide );
                    ?>
                    <section
                        class="mobilgo-hero-slide mobilgo-hero-align-<?php echo esc_attr( $slide_style_data['content_align'] ); ?><?php echo esc_attr( $active_class ); ?>"
                        style="<?php echo esc_attr( $slide_style_data['style'] ); ?>"
                    >
                        <div class="mobilgo-hero-media">
                            <?php if ( 'video' === $bg_type && ! empty( $bg_video ) ) : ?>
                                <div class="mobilgo-hero-video">
                                    <video autoplay muted loop playsinline preload="auto">
                                        <source src="<?php echo esc_url( $bg_video ); ?>" type="video/mp4">
                                    </video>
                                </div>
                            <?php elseif ( ! empty( $bg_image ) ) : ?>
                                <div class="mobilgo-hero-image" style="background-image:url('<?php echo esc_url( $bg_image ); ?>');"></div>
                            <?php else : ?>
                                <div class="mobilgo-hero-image mobilgo-hero-image--fallback"></div>
                            <?php endif; ?>

                            <div class="mobilgo-hero-overlay"></div>
                        </div>

                        <div class="mobilgo-hero-content">
                            <div class="container">
                                <div class="mobilgo-hero-inner">
                                    <?php if ( ! empty( $slide['heading'] ) ) : ?>
                                        <h1 class="mobilgo-hero-title"><?php echo esc_html( $slide['heading'] ); ?></h1>
                                    <?php endif; ?>

                                    <?php if ( ! empty( $slide['subheading'] ) ) : ?>
                                        <div class="mobilgo-hero-subtitle"><?php echo nl2br( esc_html( $slide['subheading'] ) ); ?></div>
                                    <?php endif; ?>

                                    <?php if ( ! empty( $slide['button_1_text'] ) || ( $button_2_on && ! empty( $slide['button_2_text'] ) ) ) : ?>
                                        <div class="mobilgo-hero-actions">
                                            <?php
                                            if ( ! empty( $slide['button_1_text'] ) ) {
                                                $this->render_button(
                                                    $slide['button_1_text'],
                                                    isset( $slide['button_1_link'] ) && is_array( $slide['button_1_link'] ) ? $slide['button_1_link'] : array(),
                                                    'primary',
                                                    $slide_style_data['button_1_style']
                                                );
                                            }

                                            if ( $button_2_on && ! empty( $slide['button_2_text'] ) ) {
                                                $this->render_button(
                                                    $slide['button_2_text'],
                                                    isset( $slide['button_2_link'] ) && is_array( $slide['button_2_link'] ) ? $slide['button_2_link'] : array(),
                                                    'secondary',
                                                    $slide_style_data['button_2_style']
                                                );
                                            }
                                            ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </section>
                <?php endforeach; ?>

                <?php if ( count( $slides ) > 1 && 'yes' === $enable_arrows ) : ?>
                    <button class="mobilgo-hero-arrow mobilgo-hero-arrow--prev" type="button" aria-label="Previous slide">‹</button>
                    <button class="mobilgo-hero-arrow mobilgo-hero-arrow--next" type="button" aria-label="Next slide">›</button>
                <?php endif; ?>
            </div>

            <?php $this->render_boxes( $boxes, $box_design_vars ); ?>
        </div>

        <?php $this->render_slider_script( $slider_id ); ?>
        <?php
    }

    protected function render_slider_script( $slider_id ) {
        ?>
        <script>
        (function() {
            var hero = document.getElementById('<?php echo esc_js( $slider_id ); ?>');
            if (!hero || hero.dataset.initialized === 'true') return;

            hero.dataset.initialized = 'true';

            var slides = hero.querySelectorAll('.mobilgo-hero-slide');
            var prevBtn = hero.querySelector('.mobilgo-hero-arrow--prev');
            var nextBtn = hero.querySelector('.mobilgo-hero-arrow--next');

            if (!slides.length) return;

            var current = 0;
            var autoplay = hero.dataset.autoplay === 'true';
            var speed = parseInt(hero.dataset.speed || '5000', 10);
            var interval = null;

            function showSlide(index) {
                slides.forEach(function(slide, i) {
                    slide.classList.toggle('is-active', i === index);
                });
                current = index;
            }

            function nextSlide() {
                var next = current + 1;
                if (next >= slides.length) next = 0;
                showSlide(next);
            }

            function prevSlide() {
                var prev = current - 1;
                if (prev < 0) prev = slides.length - 1;
                showSlide(prev);
            }

            function startAutoplay() {
                if (!autoplay || slides.length < 2) return;
                stopAutoplay();
                interval = setInterval(nextSlide, speed);
            }

            function stopAutoplay() {
                if (interval) {
                    clearInterval(interval);
                    interval = null;
                }
            }

            if (nextBtn) {
                nextBtn.addEventListener('click', function() {
                    nextSlide();
                    startAutoplay();
                });
            }

            if (prevBtn) {
                prevBtn.addEventListener('click', function() {
                    prevSlide();
                    startAutoplay();
                });
            }

            hero.addEventListener('mouseenter', stopAutoplay);
            hero.addEventListener('mouseleave', startAutoplay);

            showSlide(0);
            startAutoplay();
        })();
        </script>
        <?php
    }
}
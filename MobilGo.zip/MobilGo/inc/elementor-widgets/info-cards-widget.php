<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MobilGo_Info_Cards_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mobilgo_info_cards';
    }

    public function get_title() {
        return 'MobilGo Info Cards';
    }

    public function get_icon() {
        return 'eicon-posts-grid';
    }

    public function get_categories() {
        return array( 'mobilgo' );
    }

    public function get_keywords() {
        return array( 'mobilgo', 'info', 'cards', 'features' );
    }

    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Content Settings',
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'card_label',
            array(
                'label'   => 'Card Label',
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => 'Card 1',
            )
        );

        $repeater->add_control(
            'card_icon',
            array(
                'label'   => 'Icon',
                'type'    => \Elementor\Controls_Manager::ICONS,
                'default' => array(
                    'value'   => 'fas fa-bolt',
                    'library' => 'fa-solid',
                ),
            )
        );

        $repeater->add_control(
            'card_title',
            array(
                'label'   => 'Title',
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => 'Hurtig & billig reparation',
            )
        );

        $repeater->add_control(
            'card_text',
            array(
                'label'   => 'Text',
                'type'    => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'Hos MobilGo får du hurtig og prisvenlig reparation af din smartphone, tablet eller PC.',
            )
        );

        $repeater->add_control(
            'card_link',
            array(
                'label'         => 'Link',
                'type'          => \Elementor\Controls_Manager::URL,
                'show_external' => true,
                'default'       => array(
                    'url' => '',
                ),
            )
        );

        $this->add_control(
            'cards',
            array(
                'label'       => 'Cards',
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ card_label }}}',
                'button_text' => 'Add Card',
                'default'     => array(
                    array(
                        'card_label' => 'Card 1',
                        'card_title' => 'Hurtig & billig reparation',
                        'card_text'  => 'Hos MobilGo får du hurtig og prisvenlig reparation af din smartphone, tablet eller PC.',
                    ),
                    array(
                        'card_label' => 'Card 2',
                        'card_icon'  => array(
                            'value'   => 'fas fa-mobile-screen',
                            'library' => 'fa-solid',
                        ),
                        'card_title' => 'iPhone, Android & tablets',
                        'card_text'  => 'Vi reparerer populære smartphones og tablets hurtigt og professionelt.',
                    ),
                    array(
                        'card_label' => 'Card 3',
                        'card_icon'  => array(
                            'value'   => 'fas fa-laptop',
                            'library' => 'fa-solid',
                        ),
                        'card_title' => 'Reparation af Mac & PC',
                        'card_text'  => 'Vi tilbyder professionel service og reparation af MacBook, PC og andre enheder.',
                    ),
                ),
            )
        );

        $this->end_controls_section();
    }

    protected function get_link_attrs( $link = array() ) {
        $link  = is_array( $link ) ? $link : array();
        $attrs = array();

        if ( ! empty( $link['url'] ) ) {
            $attrs[] = 'href="' . esc_url( $link['url'] ) . '"';
        } else {
            $attrs[] = 'href="#"';
        }

        $rels = array();

        if ( ! empty( $link['is_external'] ) ) {
            $attrs[] = 'target="_blank"';
            $rels[]  = 'noopener';
        }

        if ( ! empty( $link['nofollow'] ) ) {
            $rels[] = 'nofollow';
        }

        if ( ! empty( $rels ) ) {
            $attrs[] = 'rel="' . esc_attr( implode( ' ', array_unique( $rels ) ) ) . '"';
        }

        return implode( ' ', $attrs );
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $cards    = ! empty( $settings['cards'] ) ? $settings['cards'] : array();

        if ( empty( $cards ) ) {
            return;
        }
        ?>
        <section class="mobilgo-info-cards">
            <div class="mobilgo-info-grid">

                <?php foreach ( $cards as $card ) : ?>
                    <?php
                    $has_link   = ! empty( $card['card_link']['url'] );
                    $link_attrs = $this->get_link_attrs( isset( $card['card_link'] ) ? $card['card_link'] : array() );
                    ?>

                    <?php if ( $has_link ) : ?>
                        <a class="mobilgo-info-card" <?php echo $link_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
                    <?php else : ?>
                        <div class="mobilgo-info-card">
                    <?php endif; ?>

                        <?php if ( ! empty( $card['card_icon']['value'] ) ) : ?>
                            <div class="mobilgo-info-icon">
                                <?php \Elementor\Icons_Manager::render_icon( $card['card_icon'], array( 'aria-hidden' => 'true' ) ); ?>
                            </div>
                        <?php endif; ?>

                        <?php if ( ! empty( $card['card_title'] ) ) : ?>
                            <h3 class="mobilgo-info-title">
                                <?php echo esc_html( $card['card_title'] ); ?>
                            </h3>
                        <?php endif; ?>

                        <?php if ( ! empty( $card['card_text'] ) ) : ?>
                            <p class="mobilgo-info-text">
                                <?php echo esc_html( $card['card_text'] ); ?>
                            </p>
                        <?php endif; ?>

                    <?php if ( $has_link ) : ?>
                        </a>
                    <?php else : ?>
                        </div>
                    <?php endif; ?>

                <?php endforeach; ?>

            </div>
        </section>
        <?php
    }
}
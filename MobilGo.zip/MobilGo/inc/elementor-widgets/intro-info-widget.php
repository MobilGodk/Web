<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MobilGo_Intro_Info_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mobilgo_intro_info';
    }

    public function get_title() {
        return 'MobilGo Intro Info';
    }

    public function get_icon() {
        return 'eicon-info-circle';
    }

    public function get_categories() {
        return array( 'mobilgo' );
    }

    public function get_keywords() {
        return array( 'mobilgo', 'intro', 'info', 'box' );
    }

    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Content Settings',
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'intro_heading',
            array(
                'label'   => 'Heading',
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => 'Vores Teknikere er altid klar til at Reparere din Enhed!',
            )
        );

        $this->add_control(
            'intro_description',
            array(
                'label'   => 'Description',
                'type'    => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'Fra iPhones og iPads til de nyeste enheder – dit lokale værksted kan reparere din mobiltelefon eller tablet på kun 30–45 minutter.',
            )
        );

        $this->add_control(
            'phone_number',
            array(
                'label'   => 'Phone Number',
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => '+45 22 66 66 69',
            )
        );

        $this->add_control(
            'phone_icon',
            array(
                'label'   => 'Phone Icon',
                'type'    => \Elementor\Controls_Manager::ICONS,
                'default' => array(
                    'value'   => 'fas fa-phone',
                    'library' => 'fa-solid',
                ),
            )
        );

        $this->add_control(
            'slogan_text',
            array(
                'label'   => 'Slogan',
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => 'Hos MobilGo er det nemt, hurtigt og økonomisk at få repareret din enhed.',
            )
        );

        $this->add_control(
            'tagline_text',
            array(
                'label'   => 'Tagline',
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => 'Your Smartphone Matters',
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings    = $this->get_settings_for_display();
        $phone_raw   = ! empty( $settings['phone_number'] ) ? $settings['phone_number'] : '';
        $phone_clean = preg_replace( '/[^0-9+]/', '', (string) $phone_raw );
        ?>
        <section class="mobilgo-intro-section">
            <div class="mobilgo-intro-box">

                <?php if ( ! empty( $settings['intro_heading'] ) ) : ?>
                    <h2 class="mobilgo-intro-title">
                        <?php echo esc_html( $settings['intro_heading'] ); ?>
                    </h2>
                <?php endif; ?>

                <?php if ( ! empty( $settings['intro_description'] ) ) : ?>
                    <p class="mobilgo-intro-text">
                        <?php echo esc_html( $settings['intro_description'] ); ?>
                    </p>
                <?php endif; ?>

                <?php if ( ! empty( $phone_raw ) ) : ?>
                    <div class="mobilgo-intro-phone">

                        <?php if ( ! empty( $settings['phone_icon']['value'] ) ) : ?>
                            <span class="mobilgo-intro-phone-icon">
                                <?php \Elementor\Icons_Manager::render_icon( $settings['phone_icon'], array( 'aria-hidden' => 'true' ) ); ?>
                            </span>
                        <?php endif; ?>

                        <a href="tel:<?php echo esc_attr( $phone_clean ); ?>">
                            <?php echo esc_html( $phone_raw ); ?>
                        </a>
                    </div>
                <?php endif; ?>

                <?php if ( ! empty( $settings['slogan_text'] ) || ! empty( $settings['tagline_text'] ) ) : ?>
                    <p class="mobilgo-intro-slogan">
                        <?php if ( ! empty( $settings['slogan_text'] ) ) : ?>
                            <span class="mobilgo-intro-slogan-text">
                                <?php echo esc_html( $settings['slogan_text'] ); ?>
                            </span>
                        <?php endif; ?>

                        <?php if ( ! empty( $settings['tagline_text'] ) ) : ?>
                            <span class="mobilgo-tagline">
                                <?php echo esc_html( $settings['tagline_text'] ); ?>
                            </span>
                        <?php endif; ?>
                    </p>
                <?php endif; ?>

            </div>
        </section>
        <?php
    }
}
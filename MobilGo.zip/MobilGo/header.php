<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$mobilgo_header_transparent = get_option( 'mobilgo_header_transparent_enable', 'yes' );
$mobilgo_header_sticky      = get_option( 'mobilgo_header_sticky_enable', 'yes' );

$mobilgo_site_logo        = get_option( 'mobilgo_site_logo', '' );
$mobilgo_site_mobile_logo = get_option( 'mobilgo_site_mobile_logo', '' );

/* =========================
   Business Info
========================= */

$mobilgo_company_name = function_exists( 'mobilgo_get_company_name' )
    ? mobilgo_get_company_name()
    : get_bloginfo( 'name' );

$mobilgo_company_phone = function_exists( 'mobilgo_get_phone' )
    ? mobilgo_get_phone()
    : get_option( 'mobilgo_company_phone', '' );

$mobilgo_company_email = function_exists( 'mobilgo_get_email' )
    ? mobilgo_get_email()
    : get_option( 'mobilgo_company_email', '' );

$mobilgo_company_address = function_exists( 'mobilgo_get_address' )
    ? mobilgo_get_address()
    : get_option( 'mobilgo_company_address', '' );

/* =========================
   Header Options Fallback
========================= */

$mobilgo_location_enable = get_option( 'mobilgo_header_locations_enable', 'yes' );
$mobilgo_location_icon   = get_option( 'mobilgo_header_location_icon', 'fa-solid fa-location-dot' );

$mobilgo_old_location_line1 = get_option( 'mobilgo_header_location_line1', 'Frederikssund - Stenløse' );
$mobilgo_old_location_line2 = get_option( 'mobilgo_header_location_line2', 'Farum - Amager' );

$mobilgo_hours_enable = get_option( 'mobilgo_header_hours_enable', 'yes' );
$mobilgo_hours_icon   = get_option( 'mobilgo_header_hours_icon_class', 'fa-regular fa-clock' );
$mobilgo_hours_line1  = get_option( 'mobilgo_header_hours_line_1', 'Mandag - Fredag 10:00 - 18:00' );
$mobilgo_hours_line2  = get_option( 'mobilgo_header_hours_line_2', 'Lørdag - Søndag 10:00 - 14:00' );

$mobilgo_contact_enable = get_option( 'mobilgo_header_contact_enable', 'yes' );
$mobilgo_contact_icon   = get_option( 'mobilgo_header_contact_icon_class', 'fa-solid fa-phone' );

/* =========================
   Locations (up to 6)
========================= */

$mobilgo_locations = function_exists( 'mobilgo_get_locations' )
    ? mobilgo_get_locations()
    : array();

$mobilgo_location_item_1 = isset( $mobilgo_locations[0] ) ? $mobilgo_locations[0] : array();
$mobilgo_location_item_2 = isset( $mobilgo_locations[1] ) ? $mobilgo_locations[1] : array();

$mobilgo_location_line1 = '';
$mobilgo_location_line2 = '';
$mobilgo_location_link1 = '';
$mobilgo_location_link2 = '';

if ( ! empty( $mobilgo_location_item_1 ) ) {
    $mobilgo_location_line1 = ! empty( $mobilgo_location_item_1['title'] )
        ? $mobilgo_location_item_1['title']
        : ( ! empty( $mobilgo_location_item_1['address'] ) ? $mobilgo_location_item_1['address'] : '' );

    $mobilgo_location_link1 = ! empty( $mobilgo_location_item_1['map'] ) ? $mobilgo_location_item_1['map'] : '';
}

if ( ! empty( $mobilgo_location_item_2 ) ) {
    $mobilgo_location_line2 = ! empty( $mobilgo_location_item_2['title'] )
        ? $mobilgo_location_item_2['title']
        : ( ! empty( $mobilgo_location_item_2['address'] ) ? $mobilgo_location_item_2['address'] : '' );

    $mobilgo_location_link2 = ! empty( $mobilgo_location_item_2['map'] ) ? $mobilgo_location_item_2['map'] : '';
}

/* fallback to old header values if no locations filled yet */
if ( empty( $mobilgo_location_line1 ) ) {
    $mobilgo_location_line1 = $mobilgo_old_location_line1;
}
if ( empty( $mobilgo_location_line2 ) ) {
    $mobilgo_location_line2 = $mobilgo_old_location_line2;
}

/* =========================
   Contact fallback
========================= */

$mobilgo_contact_phone = ! empty( $mobilgo_company_phone )
    ? $mobilgo_company_phone
    : get_option( 'mobilgo_header_phone', '+45 22 66 66 69' );

$mobilgo_contact_email = ! empty( $mobilgo_company_email )
    ? $mobilgo_company_email
    : get_option( 'mobilgo_header_email', 'info@mobilgo.dk' );

$mobilgo_phone_clean = preg_replace( '/[^0-9+]/', '', (string) $mobilgo_contact_phone );

/* =========================
   Header Classes
========================= */

$mobilgo_header_classes = array( 'mobilgo-header' );

if ( 'yes' === $mobilgo_header_transparent ) {
    $mobilgo_header_classes[] = 'mobilgo-header--transparent';
} else {
    $mobilgo_header_classes[] = 'mobilgo-header--solid';
}

if ( 'yes' === $mobilgo_header_sticky ) {
    $mobilgo_header_classes[] = 'mobilgo-header--sticky';
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<?php wp_body_open(); ?>

<header class="<?php echo esc_attr( implode( ' ', $mobilgo_header_classes ) ); ?>">
    <div class="mobilgo-header-shell">
        <div class="container">

            <div class="mobilgo-header-top">

                <div class="mobilgo-header-logo">
                    <?php if ( ! empty( $mobilgo_site_logo ) ) : ?>

                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="mobilgo-header-logo-link">
                            <img
                                src="<?php echo esc_url( $mobilgo_site_logo ); ?>"
                                class="mobilgo-desktop-logo"
                                alt="<?php echo esc_attr( $mobilgo_company_name ); ?>"
                            >

                            <?php if ( ! empty( $mobilgo_site_mobile_logo ) ) : ?>
                                <img
                                    src="<?php echo esc_url( $mobilgo_site_mobile_logo ); ?>"
                                    class="mobilgo-mobile-logo"
                                    alt="<?php echo esc_attr( $mobilgo_company_name ); ?>"
                                >
                            <?php endif; ?>
                        </a>

                    <?php elseif ( has_custom_logo() ) : ?>

                        <div class="mobilgo-header-logo-link mobilgo-header-logo-link--custom">
                            <?php the_custom_logo(); ?>
                        </div>

                    <?php else : ?>

                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="mobilgo-header-logo-link">
                            <span class="mobilgo-logo-text"><?php echo esc_html( $mobilgo_company_name ); ?></span>
                        </a>

                    <?php endif; ?>
                </div>

                <div class="mobilgo-header-info">

                    <?php if ( 'yes' === $mobilgo_location_enable ) : ?>
                        <div class="mobilgo-header-info__item">
                            <div class="mobilgo-header-info__icon">
                                <?php
                                if ( function_exists( 'mobilgo_render_icon' ) ) {
                                    echo mobilgo_render_icon( $mobilgo_location_icon, 'fa' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                                } else {
                                    ?>
                                    <i class="<?php echo esc_attr( $mobilgo_location_icon ); ?>" aria-hidden="true"></i>
                                    <?php
                                }
                                ?>
                            </div>

                            <div class="mobilgo-header-info__content">
                                <?php if ( ! empty( $mobilgo_location_line1 ) ) : ?>
                                    <?php if ( ! empty( $mobilgo_location_link1 ) ) : ?>
                                        <a href="<?php echo esc_url( $mobilgo_location_link1 ); ?>" class="mobilgo-header-info__line">
                                            <?php echo esc_html( $mobilgo_location_line1 ); ?>
                                        </a>
                                    <?php else : ?>
                                        <span class="mobilgo-header-info__line">
                                            <?php echo esc_html( $mobilgo_location_line1 ); ?>
                                        </span>
                                    <?php endif; ?>
                                <?php endif; ?>

                                <?php if ( ! empty( $mobilgo_location_line2 ) ) : ?>
                                    <?php if ( ! empty( $mobilgo_location_link2 ) ) : ?>
                                        <a href="<?php echo esc_url( $mobilgo_location_link2 ); ?>" class="mobilgo-header-info__line">
                                            <?php echo esc_html( $mobilgo_location_line2 ); ?>
                                        </a>
                                    <?php else : ?>
                                        <span class="mobilgo-header-info__line">
                                            <?php echo esc_html( $mobilgo_location_line2 ); ?>
                                        </span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if ( 'yes' === $mobilgo_hours_enable ) : ?>
                        <div class="mobilgo-header-info__item">
                            <div class="mobilgo-header-info__icon">
                                <?php
                                if ( function_exists( 'mobilgo_render_icon' ) ) {
                                    echo mobilgo_render_icon( $mobilgo_hours_icon, 'fa' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                                } else {
                                    ?>
                                    <i class="<?php echo esc_attr( $mobilgo_hours_icon ); ?>" aria-hidden="true"></i>
                                    <?php
                                }
                                ?>
                            </div>

                            <div class="mobilgo-header-info__content">
                                <?php if ( ! empty( $mobilgo_hours_line1 ) ) : ?>
                                    <span class="mobilgo-header-info__line">
                                        <?php echo esc_html( $mobilgo_hours_line1 ); ?>
                                    </span>
                                <?php endif; ?>

                                <?php if ( ! empty( $mobilgo_hours_line2 ) ) : ?>
                                    <span class="mobilgo-header-info__line">
                                        <?php echo esc_html( $mobilgo_hours_line2 ); ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>

                <?php if ( 'yes' === $mobilgo_contact_enable ) : ?>
                    <div class="mobilgo-header-contact">
                        <div class="mobilgo-header-contact__icon">
                            <?php
                            if ( function_exists( 'mobilgo_render_icon' ) ) {
                                echo mobilgo_render_icon( $mobilgo_contact_icon, 'fa' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                            } else {
                                ?>
                                <i class="<?php echo esc_attr( $mobilgo_contact_icon ); ?>" aria-hidden="true"></i>
                                <?php
                            }
                            ?>
                        </div>

                        <div class="mobilgo-header-contact__content">
                            <?php if ( ! empty( $mobilgo_contact_phone ) ) : ?>
                                <a href="tel:<?php echo esc_attr( $mobilgo_phone_clean ); ?>" class="mobilgo-header-contact__phone">
                                    <?php echo esc_html( $mobilgo_contact_phone ); ?>
                                </a>
                            <?php endif; ?>

                            <?php if ( ! empty( $mobilgo_contact_email ) ) : ?>
                                <a href="mailto:<?php echo esc_attr( antispambot( $mobilgo_contact_email ) ); ?>" class="mobilgo-header-contact__mail">
                                    <?php echo esc_html( antispambot( $mobilgo_contact_email ) ); ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <button
                    class="mobilgo-menu-toggle"
                    type="button"
                    aria-label="<?php echo esc_attr__( 'Open menu', 'mobilgo' ); ?>"
                    aria-expanded="false"
                    aria-controls="mobilgo-mobile-menu"
                >
                    <span></span>
                    <span></span>
                    <span></span>
                </button>

            </div>

            <div class="mobilgo-header-nav-wrap">
                <nav class="mobilgo-header-nav" aria-label="<?php echo esc_attr__( 'Main Menu', 'mobilgo' ); ?>">
                    <?php
                    wp_nav_menu(
                        array(
                            'theme_location' => 'main-menu',
                            'container'      => false,
                            'menu_class'     => 'mobilgo-menu',
                            'fallback_cb'    => false,
                        )
                    );
                    ?>
                </nav>
            </div>

            <div id="mobilgo-mobile-menu" class="mobilgo-mobile-menu">
                <?php
                wp_nav_menu(
                    array(
                        'theme_location' => 'main-menu',
                        'container'      => false,
                        'menu_class'     => 'mobilgo-mobile-menu__list',
                        'fallback_cb'    => false,
                    )
                );
                ?>
            </div>

        </div>
    </div>
</header>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var toggle = document.querySelector('.mobilgo-menu-toggle');
    var menu   = document.querySelector('.mobilgo-mobile-menu');

    if (!toggle || !menu) {
        return;
    }

    toggle.addEventListener('click', function () {
        menu.classList.toggle('is-active');
        toggle.classList.toggle('is-active');

        var expanded = menu.classList.contains('is-active') ? 'true' : 'false';
        toggle.setAttribute('aria-expanded', expanded);
    });
});
</script>
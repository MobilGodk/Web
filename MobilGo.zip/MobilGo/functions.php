<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* =========================
   Theme Setup
========================= */

function mobilgo_theme_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'custom-logo' );
    add_theme_support( 'menus' );
    add_theme_support( 'post-thumbnails' );

    register_nav_menus(
        array(
            'main-menu' => __( 'Main Menu', 'mobilgo' ),
        )
    );

    $lang_dir = get_template_directory() . '/languages';
    if ( is_dir( $lang_dir ) ) {
        load_theme_textdomain( 'mobilgo', $lang_dir );
    }
}
add_action( 'after_setup_theme', 'mobilgo_theme_setup' );

/* =========================
   Theme Settings Loader
========================= */

function mobilgo_load_theme_settings() {
    $theme_dir = get_template_directory();

    $files = array(
        '/inc/helpers/icon-system.php',
        '/inc/helpers/business-info.php',

        '/inc/theme-settings/admin-ui.php',
        '/inc/theme-settings/general-settings.php',
        '/inc/theme-settings/header-settings.php',
        '/inc/theme-settings/footer-settings.php',
        '/inc/theme-settings/shop-settings.php',
        '/inc/theme-settings/design-settings.php',
    );

    foreach ( $files as $file ) {
        $path = $theme_dir . $file;

        if ( file_exists( $path ) && is_readable( $path ) ) {
            require_once $path;
        }
    }
}
add_action( 'after_setup_theme', 'mobilgo_load_theme_settings', 1 );

/* =========================
   Load Theme Assets
========================= */

function mobilgo_theme_assets() {
    $theme_dir = get_template_directory();
    $theme_uri = get_template_directory_uri();

    $assets = array(
        'mobilgo-style'         => '/style.css',
        'mobilgo-global'        => '/assets/css/global.css',
        'mobilgo-header'        => '/assets/css/header.css',
        'mobilgo-hero'          => '/assets/css/hero.css',
        'mobilgo-intro-info'    => '/assets/css/intro-info.css',
        'mobilgo-info-cards'    => '/assets/css/info-cards.css',
        'mobilgo-repair-brands' => '/assets/css/repair-brands.css',
    );

    foreach ( $assets as $handle => $relative_path ) {
        $absolute_path = $theme_dir . $relative_path;
        $version       = file_exists( $absolute_path ) ? filemtime( $absolute_path ) : '1.0';
        $deps          = array();

        if ( 'mobilgo-global' === $handle ) {
            $deps = array( 'mobilgo-style' );
        } elseif ( 'mobilgo-header' === $handle || 'mobilgo-hero' === $handle || 'mobilgo-intro-info' === $handle || 'mobilgo-info-cards' === $handle || 'mobilgo-repair-brands' === $handle ) {
            $deps = array( 'mobilgo-global' );
        }

        wp_enqueue_style(
            $handle,
            $theme_uri . $relative_path,
            $deps,
            $version
        );
    }

    wp_enqueue_style(
        'mobilgo-font-awesome',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css',
        array(),
        '6.5.1'
    );
}
add_action( 'wp_enqueue_scripts', 'mobilgo_theme_assets', 5 );

/* =========================
   Elementor Widget Category
========================= */

function mobilgo_elementor_widget_categories( $elements_manager ) {
    $elements_manager->add_category(
        'mobilgo',
        array(
            'title' => __( 'MobilGo Widgets', 'mobilgo' ),
            'icon'  => 'eicon-plug',
        )
    );
}
add_action( 'elementor/elements/categories_registered', 'mobilgo_elementor_widget_categories' );

/* =========================
   Register Elementor Widgets
========================= */

function mobilgo_register_elementor_widgets( $widgets_manager ) {
    $theme_dir = get_template_directory();

    $widget_files = array(
        $theme_dir . '/inc/elementor-widgets/hero-widget.php',
        $theme_dir . '/inc/elementor-widgets/intro-info-widget.php',
        $theme_dir . '/inc/elementor-widgets/info-cards-widget.php',
        $theme_dir . '/inc/elementor-widgets/repair-brands-widget.php',
    );

    foreach ( $widget_files as $widget_file ) {
        if ( file_exists( $widget_file ) && is_readable( $widget_file ) ) {
            require_once $widget_file;
        }
    }

    if ( class_exists( 'MobilGo_Hero_Widget' ) ) {
        $widgets_manager->register( new MobilGo_Hero_Widget() );
    }

    if ( class_exists( 'MobilGo_Intro_Info_Widget' ) ) {
        $widgets_manager->register( new MobilGo_Intro_Info_Widget() );
    }

    if ( class_exists( 'MobilGo_Info_Cards_Widget' ) ) {
        $widgets_manager->register( new MobilGo_Info_Cards_Widget() );
    }

    if ( class_exists( 'MobilGo_repair_brands_widget' ) ) {
        $widgets_manager->register( new MobilGo_repair_brands_widget() );
    }
}
add_action( 'elementor/widgets/register', 'mobilgo_register_elementor_widgets' );

/* =========================
   Defer Frontend Scripts
========================= */

add_filter(
    'script_loader_tag',
    function( $tag, $handle ) {
        if ( is_admin() ) {
            return $tag;
        }

        return str_replace( '<script ', '<script defer ', $tag );
    },
    10,
    2
);

/* =========================
   Print Theme Design Variables
========================= */

function mobilgo_print_theme_design_variables() {
    $primary       = get_option( 'mobilgo_primary_color', '#d10000' );
    $primary_hover = get_option( 'mobilgo_primary_hover_color', '#a80000' );
    $text          = get_option( 'mobilgo_text_color', '#111111' );
    $text_light    = get_option( 'mobilgo_text_light_color', '#555555' );
    $box_bg        = get_option( 'mobilgo_box_bg_color', '#ffffff' );
    $border        = get_option( 'mobilgo_border_color', '#eeeeee' );
    $tag_bg        = get_option( 'mobilgo_tag_bg_color', '#efefef' );

    echo '<style id="mobilgo-theme-design-vars">:root{';
    echo '--mobilgo-primary:' . esc_attr( $primary ) . ';';
    echo '--mobilgo-primary-hover:' . esc_attr( $primary_hover ) . ';';
    echo '--mobilgo-text:' . esc_attr( $text ) . ';';
    echo '--mobilgo-text-light:' . esc_attr( $text_light ) . ';';
    echo '--mobilgo-box-bg:' . esc_attr( $box_bg ) . ';';
    echo '--mobilgo-border:' . esc_attr( $border ) . ';';
    echo '--mobilgo-tag-bg:' . esc_attr( $tag_bg ) . ';';
    echo '}</style>';
}
add_action( 'wp_head', 'mobilgo_print_theme_design_variables', 20 );
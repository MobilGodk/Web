<?php
/**
 * Plugin Name: MobilGo System
 * Plugin URI: https://mobilgo.dk
 * Description: Core system for MobilGo business info, locations, business hours, holidays and store finder.
 * Version: 1.0.0
 * Author: MobilGo
 * Text Domain: mobilgo-system
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* =========================
   Constants
========================= */

define( 'MOBILGO_SYSTEM_VERSION', '1.0.0' );
define( 'MOBILGO_SYSTEM_PATH', plugin_dir_path( __FILE__ ) );
define( 'MOBILGO_SYSTEM_URL', plugin_dir_url( __FILE__ ) );

/* =========================
   Load Files
========================= */

require_once MOBILGO_SYSTEM_PATH . 'includes/helpers/location-helpers.php';
require_once MOBILGO_SYSTEM_PATH . 'includes/helpers/hours-helpers.php';
require_once MOBILGO_SYSTEM_PATH . 'includes/helpers/holiday-helpers.php';

require_once MOBILGO_SYSTEM_PATH . 'includes/admin/general-page.php';
require_once MOBILGO_SYSTEM_PATH . 'includes/admin/business-hours-holidays-page.php';
require_once MOBILGO_SYSTEM_PATH . 'includes/admin/settings-page.php';

require_once MOBILGO_SYSTEM_PATH . 'includes/post-types/location-post-type.php';
require_once MOBILGO_SYSTEM_PATH . 'includes/meta-boxes/location-meta-box.php';
require_once MOBILGO_SYSTEM_PATH . 'includes/shortcodes/store-locator-shortcode.php';

/* =========================
   Activation / Deactivation
========================= */

function mobilgo_system_activate() {
    if ( function_exists( 'mobilgo_system_register_location_post_type' ) ) {
        mobilgo_system_register_location_post_type();
    }

    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'mobilgo_system_activate' );

function mobilgo_system_deactivate() {
    flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'mobilgo_system_deactivate' );

/* =========================
   Admin Menu
========================= */

function mobilgo_system_register_admin_menu() {

    add_menu_page(
        'MobilGo System',
        'MobilGo System',
        'manage_options',
        'mobilgo-system-general',
        'mobilgo_system_render_general_page',
        'dashicons-store',
        58
    );

    add_submenu_page(
        'mobilgo-system-general',
        'General',
        'General',
        'manage_options',
        'mobilgo-system-general',
        'mobilgo_system_render_general_page'
    );

    add_submenu_page(
        'mobilgo-system-general',
        'Locations',
        'Locations',
        'manage_options',
        'edit.php?post_type=mobilgo_location'
    );

    add_submenu_page(
        'mobilgo-system-general',
        'Business Hours & Holidays',
        'Business Hours & Holidays',
        'manage_options',
        'mobilgo-system-business-hours-holidays',
        'mobilgo_system_render_business_hours_holidays_page'
    );

    add_submenu_page(
        'mobilgo-system-general',
        'Settings',
        'Settings',
        'manage_options',
        'mobilgo-system-settings',
        'mobilgo_system_render_settings_page'
    );
}
add_action( 'admin_menu', 'mobilgo_system_register_admin_menu' );

/* =========================
   Admin Assets
========================= */

function mobilgo_system_admin_assets( $hook ) {
    global $post_type;

    if ( 'mobilgo_location' !== $post_type ) {
        return;
    }

    $api_key = '';
    if ( function_exists( 'mobilgo_system_get_google_maps_api_key' ) ) {
        $api_key = mobilgo_system_get_google_maps_api_key();
    }

    if ( ! empty( $api_key ) ) {
        wp_enqueue_script(
            'mobilgo-system-google-maps-admin',
            'https://maps.googleapis.com/maps/api/js?key=' . rawurlencode( $api_key ) . '&libraries=places',
            array(),
            null,
            true
        );
    }

    wp_enqueue_script(
        'mobilgo-system-address-autocomplete',
        MOBILGO_SYSTEM_URL . 'assets/js/address-autocomplete.js',
        array( 'mobilgo-system-google-maps-admin' ),
        MOBILGO_SYSTEM_VERSION,
        true
    );
}
add_action( 'admin_enqueue_scripts', 'mobilgo_system_admin_assets' );

/* =========================
   Frontend Assets
========================= */

function mobilgo_system_frontend_assets() {

    if ( ! is_page( 'find-store' ) ) {
        return;
    }

    $api_key = '';
    if ( function_exists( 'mobilgo_system_get_google_maps_api_key' ) ) {
        $api_key = mobilgo_system_get_google_maps_api_key();
    }

    wp_enqueue_style(
    'mobilgo-system-admin-ui',
    get_template_directory_uri() . '/assets/admin/css/admin-ui.css',
    array(),
    wp_get_theme()->get( 'Version' )
);

    if ( ! empty( $api_key ) ) {
        wp_enqueue_script(
            'mobilgo-system-google-maps-frontend',
            'https://maps.googleapis.com/maps/api/js?key=' . rawurlencode( $api_key ) . '&libraries=places',
            array(),
            null,
            true
        );
    }

    wp_enqueue_script(
        'mobilgo-system-store-locator-script',
        MOBILGO_SYSTEM_URL . 'assets/js/store-locator.js',
        array( 'mobilgo-system-google-maps-frontend' ),
        MOBILGO_SYSTEM_VERSION,
        true
    );

    wp_localize_script(
        'mobilgo-system-store-locator-script',
        'mobilgoStoreLocator',
        array(
            'defaultLat'           => 55.6761,
            'defaultLng'           => 12.5683,
            'defaultZoom'          => 10,
            'browserNoGeolocation' => 'Your browser does not support location access.',
            'locationUnavailable'  => 'Your location is unavailable.',
            'nearestStoreLabel'    => 'Nearest store',
            'callLabel'            => 'Call',
            'directionsLabel'      => 'Directions',
            'useMyLocationLabel'   => 'Use My Location',
            'locatingLabel'        => 'Locating...',
        )
    );
}
add_action( 'wp_enqueue_scripts', 'mobilgo_system_frontend_assets' );
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* =========================
   Sanitize Google Maps API Key
========================= */

function mobilgo_system_sanitize_google_maps_api_key( $input ) {
    $input = is_string( $input ) ? trim( $input ) : '';
    return sanitize_text_field( $input );
}

/* =========================
   Register Settings
========================= */

function mobilgo_system_register_settings_page() {

    register_setting(
        'mobilgo_system_settings_group',
        'mobilgo_google_maps_api_key',
        array(
            'sanitize_callback' => 'mobilgo_system_sanitize_google_maps_api_key',
            'default'           => '',
        )
    );

}
add_action( 'admin_init', 'mobilgo_system_register_settings_page' );


/* =========================
   Get Google API Key
========================= */

function mobilgo_system_get_google_maps_api_key() {
    return get_option( 'mobilgo_google_maps_api_key', '' );
}


/* =========================
   Render Settings Page
========================= */

function mobilgo_system_render_settings_page() {

    $api_key = get_option( 'mobilgo_google_maps_api_key', '' );
    $theme   = wp_get_theme();
    $count   = wp_count_posts( 'mobilgo_location' );
    $version = defined( 'MOBILGO_SYSTEM_VERSION' ) ? MOBILGO_SYSTEM_VERSION : '1.0.0';

    ?>
    <div class="wrap mobilgo-admin-wrap">

        <div class="mobilgo-admin-hero">

            <div class="mobilgo-admin-hero-top">

                <div class="mobilgo-admin-brand">
                    <h1 class="mobilgo-admin-brand-title">
                        <strong>MobilGo</strong> System
                    </h1>
                </div>

                <span class="mobilgo-admin-version">
                    v<?php echo esc_html( $version ); ?>
                </span>

            </div>

            <p class="mobilgo-admin-subtitle">
                System configuration and external integrations
            </p>

            <div class="mobilgo-admin-nav">

                <a href="<?php echo esc_url( admin_url( 'admin.php?page=mobilgo-system-general' ) ); ?>">
                    General
                </a>

                <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=mobilgo_location' ) ); ?>">
                    Locations
                </a>

                <a href="<?php echo esc_url( admin_url( 'admin.php?page=mobilgo-system-business-hours-holidays' ) ); ?>">
                    Business Hours & Holidays
                </a>

                <a href="<?php echo esc_url( admin_url( 'admin.php?page=mobilgo-system-settings' ) ); ?>" class="is-active">
                    Settings
                </a>

            </div>

        </div>

        <div class="mobilgo-admin-grid">

            <div class="mobilgo-admin-card">

                <h2>Google Maps API</h2>

                <p class="mobilgo-admin-card-desc">
                    This API key is used for:
                    <br>
                    • Address autocomplete when adding locations
                    <br>
                    • Store finder map
                    <br>
                    • Location coordinates
                </p>

                <form method="post" action="options.php">

                    <?php settings_fields( 'mobilgo_system_settings_group' ); ?>

                    <table class="form-table">

                        <tr>
                            <th scope="row">Google Maps API Key</th>
                            <td>
                                <input
                                    type="text"
                                    class="regular-text"
                                    name="mobilgo_google_maps_api_key"
                                    value="<?php echo esc_attr( $api_key ); ?>"
                                    placeholder="AIza..."
                                    autocomplete="off"
                                    spellcheck="false"
                                >

                                <p class="description">
                                    Get your key from Google Cloud → Maps Platform
                                </p>
                            </td>
                        </tr>

                    </table>

                    <?php submit_button( 'Save Settings' ); ?>

                </form>

            </div>

            <div class="mobilgo-admin-card">

                <h2>System Information</h2>

                <p class="mobilgo-admin-card-desc">
                    Useful information for debugging or future integrations.
                </p>

                <table class="form-table">

                    <tr>
                        <th scope="row">Plugin Version</th>
                        <td>
                            <?php echo esc_html( $version ); ?>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">WordPress Version</th>
                        <td>
                            <?php echo esc_html( get_bloginfo( 'version' ) ); ?>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">Theme</th>
                        <td>
                            <?php echo esc_html( $theme->get( 'Name' ) ); ?>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">Locations Count</th>
                        <td>
                            <?php echo esc_html( isset( $count->publish ) ? $count->publish : 0 ); ?>
                        </td>
                    </tr>

                </table>

            </div>

        </div>

    </div>
    <?php
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* =========================
   Register General Settings
========================= */

function mobilgo_system_register_general_settings() {

    register_setting(
        'mobilgo_system_general_group',
        'mobilgo_business_name',
        array(
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '',
        )
    );

    register_setting(
        'mobilgo_system_general_group',
        'mobilgo_main_phone',
        array(
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '',
        )
    );

    register_setting(
        'mobilgo_system_general_group',
        'mobilgo_main_email',
        array(
            'sanitize_callback' => 'sanitize_email',
            'default'           => '',
        )
    );

    register_setting(
        'mobilgo_system_general_group',
        'mobilgo_vat_cvr',
        array(
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '',
        )
    );

    register_setting(
        'mobilgo_system_general_group',
        'mobilgo_site_logo',
        array(
            'sanitize_callback' => 'esc_url_raw',
            'default'           => '',
        )
    );

    register_setting(
        'mobilgo_system_general_group',
        'mobilgo_site_mobile_logo',
        array(
            'sanitize_callback' => 'esc_url_raw',
            'default'           => '',
        )
    );

    register_setting(
        'mobilgo_system_general_group',
        'mobilgo_favicon_url',
        array(
            'sanitize_callback' => 'esc_url_raw',
            'default'           => '',
        )
    );

    register_setting(
        'mobilgo_system_general_group',
        'mobilgo_inner_page_header_image',
        array(
            'sanitize_callback' => 'esc_url_raw',
            'default'           => '',
        )
    );
}
add_action( 'admin_init', 'mobilgo_system_register_general_settings' );


/* =========================
   Render General Page
========================= */

function mobilgo_system_render_general_page() {
    ?>
    <div class="wrap mobilgo-admin-wrap">

        <div class="mobilgo-admin-hero">
            <div class="mobilgo-admin-hero-top">
                <div class="mobilgo-admin-brand">
                    <h1 class="mobilgo-admin-brand-title">
                        <strong>MobilGo</strong> System
                    </h1>
                </div>

                <span class="mobilgo-admin-version">
                    v1.0.0
                </span>
            </div>

            <p class="mobilgo-admin-subtitle">
                Manage your business info, locations, hours, holidays and maps
            </p>

            <div class="mobilgo-admin-nav">
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=mobilgo-system-general' ) ); ?>" class="is-active">
                    General
                </a>

                <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=mobilgo_location' ) ); ?>">
                    Locations
                </a>

                <a href="<?php echo esc_url( admin_url( 'admin.php?page=mobilgo-system-business-hours-holidays' ) ); ?>">
                    Business Hours & Holidays
                </a>

                <a href="<?php echo esc_url( admin_url( 'admin.php?page=mobilgo-system-settings' ) ); ?>">
                    Settings
                </a>
            </div>
        </div>

        <div class="mobilgo-admin-grid">

            <div class="mobilgo-admin-card">
                <h2>General Business Info</h2>
                <p class="mobilgo-admin-card-desc">
                    Manage the core business data used across the MobilGo system.
                </p>

                <form method="post" action="options.php">
                    <?php settings_fields( 'mobilgo_system_general_group' ); ?>

                    <table class="form-table">

                        <tr>
                            <th scope="row">Business Name</th>
                            <td>
                                <input
                                    type="text"
                                    class="regular-text"
                                    name="mobilgo_business_name"
                                    value="<?php echo esc_attr( get_option( 'mobilgo_business_name', '' ) ); ?>"
                                >
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">Main Phone</th>
                            <td>
                                <input
                                    type="text"
                                    class="regular-text"
                                    name="mobilgo_main_phone"
                                    value="<?php echo esc_attr( get_option( 'mobilgo_main_phone', '' ) ); ?>"
                                >
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">Main Email</th>
                            <td>
                                <input
                                    type="email"
                                    class="regular-text"
                                    name="mobilgo_main_email"
                                    value="<?php echo esc_attr( get_option( 'mobilgo_main_email', '' ) ); ?>"
                                >
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">VAT / CVR</th>
                            <td>
                                <input
                                    type="text"
                                    class="regular-text"
                                    name="mobilgo_vat_cvr"
                                    value="<?php echo esc_attr( get_option( 'mobilgo_vat_cvr', '' ) ); ?>"
                                >
                            </td>
                        </tr>

                    </table>

                    <?php submit_button( 'Save Business Info' ); ?>
                </form>
            </div>

            <div class="mobilgo-admin-card">
                <h2>Brand Assets</h2>
                <p class="mobilgo-admin-card-desc">
                    Keep your logo and brand image URLs in one place for easy future integration.
                </p>

                <form method="post" action="options.php">
                    <?php settings_fields( 'mobilgo_system_general_group' ); ?>

                    <table class="form-table">

                        <tr>
                            <th scope="row">Site Logo URL</th>
                            <td>
                                <input
                                    type="url"
                                    class="regular-text"
                                    name="mobilgo_site_logo"
                                    value="<?php echo esc_attr( get_option( 'mobilgo_site_logo', '' ) ); ?>"
                                >
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">Site Mobile Logo URL</th>
                            <td>
                                <input
                                    type="url"
                                    class="regular-text"
                                    name="mobilgo_site_mobile_logo"
                                    value="<?php echo esc_attr( get_option( 'mobilgo_site_mobile_logo', '' ) ); ?>"
                                >
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">Favicon URL</th>
                            <td>
                                <input
                                    type="url"
                                    class="regular-text"
                                    name="mobilgo_favicon_url"
                                    value="<?php echo esc_attr( get_option( 'mobilgo_favicon_url', '' ) ); ?>"
                                >
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">Inner Page Header Image URL</th>
                            <td>
                                <input
                                    type="url"
                                    class="regular-text"
                                    name="mobilgo_inner_page_header_image"
                                    value="<?php echo esc_attr( get_option( 'mobilgo_inner_page_header_image', '' ) ); ?>"
                                >
                            </td>
                        </tr>

                    </table>

                    <?php submit_button( 'Save Brand Assets' ); ?>
                </form>
            </div>

        </div>

    </div>
    <?php
}
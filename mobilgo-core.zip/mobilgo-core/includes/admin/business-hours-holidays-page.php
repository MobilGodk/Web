<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* =========================
   Sanitize Global Business Hours
========================= */

function mobilgo_system_sanitize_global_business_hours( $input ) {
    $input = is_string( $input ) ? $input : '';
    $lines = preg_split( '/\r\n|\r|\n/', $input );
    $clean = array();

    foreach ( $lines as $line ) {
        $line = trim( $line );

        if ( '' === $line ) {
            continue;
        }

        $parts = array_map( 'trim', explode( '|', $line ) );

        if ( 2 === count( $parts ) ) {
            if ( in_array( strtolower( $parts[0] ), array( 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday' ), true ) && 'closed' === strtolower( $parts[1] ) ) {
                $clean[] = strtolower( $parts[0] ) . '|closed';
            }
        } elseif ( 3 === count( $parts ) ) {
            if ( in_array( strtolower( $parts[0] ), array( 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday' ), true ) ) {
                $clean[] = strtolower( $parts[0] ) . '|' . $parts[1] . '|' . $parts[2];
            }
        }
    }

    return implode( "\n", $clean );
}

/* =========================
   Sanitize Global Holidays
========================= */

function mobilgo_system_sanitize_global_holidays( $input ) {
    $input = is_string( $input ) ? $input : '';
    $lines = preg_split( '/\r\n|\r|\n/', $input );
    $clean = array();

    foreach ( $lines as $line ) {
        $line = trim( $line );

        if ( '' === $line ) {
            continue;
        }

        $parts = array_map( 'trim', explode( '|', $line ) );

        if ( 2 === count( $parts ) ) {
            if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $parts[0] ) && 'closed' === strtolower( $parts[1] ) ) {
                $clean[] = $parts[0] . '|closed';
            }
        } elseif ( 3 === count( $parts ) ) {
            if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $parts[0] ) ) {
                $clean[] = $parts[0] . '|' . $parts[1] . '|' . $parts[2];
            }
        }
    }

    return implode( "\n", $clean );
}

/* =========================
   Register Business Hours & Holidays Settings
========================= */

function mobilgo_system_register_business_hours_holidays_settings() {

    register_setting(
        'mobilgo_system_business_hours_holidays_group',
        'mobilgo_global_business_hours',
        array(
            'sanitize_callback' => 'mobilgo_system_sanitize_global_business_hours',
            'default'           => '',
        )
    );

    register_setting(
        'mobilgo_system_business_hours_holidays_group',
        'mobilgo_global_holidays',
        array(
            'sanitize_callback' => 'mobilgo_system_sanitize_global_holidays',
            'default'           => '',
        )
    );

}
add_action( 'admin_init', 'mobilgo_system_register_business_hours_holidays_settings' );


/* =========================
   Render Business Hours & Holidays Page
========================= */

function mobilgo_system_render_business_hours_holidays_page() {
    ?>
    <div class="wrap mobilgo-admin-wrap">

        <div class="mobilgo-admin-hero">
            <div class="mobilgo-admin-hero-top">
                <div class="mobilgo-admin-brand">
                    <h1 class="mobilgo-admin-brand-title">
                        <strong>MobilGo</strong> System
                    </h1>
                </div>

                <span class="mobilgo-admin-version">
                    v1.0.0
                </span>
            </div>

            <p class="mobilgo-admin-subtitle">
                Manage your business info, locations, hours, holidays and maps
            </p>

            <div class="mobilgo-admin-nav">
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=mobilgo-system-general' ) ); ?>">
                    General
                </a>

                <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=mobilgo_location' ) ); ?>">
                    Locations
                </a>

                <a href="<?php echo esc_url( admin_url( 'admin.php?page=mobilgo-system-business-hours-holidays' ) ); ?>" class="is-active">
                    Business Hours & Holidays
                </a>

                <a href="<?php echo esc_url( admin_url( 'admin.php?page=mobilgo-system-settings' ) ); ?>">
                    Settings
                </a>
            </div>
        </div>

        <div class="mobilgo-admin-grid">

            <div class="mobilgo-admin-card">
                <h2>Global Business Hours</h2>
                <p class="mobilgo-admin-card-desc">
                    These hours are used for all locations by default. A location can override them with its own hours.
                </p>

                <form method="post" action="options.php">
                    <?php settings_fields( 'mobilgo_system_business_hours_holidays_group' ); ?>

                    <table class="form-table">
                        <tr>
                            <th scope="row">Global Business Hours</th>
                            <td>
                                <textarea
                                    name="mobilgo_global_business_hours"
                                    rows="10"
                                    class="large-text code"
                                ><?php echo esc_textarea( get_option( 'mobilgo_global_business_hours', '' ) ); ?></textarea>

                                <p class="description">
                                    One line per day. Format:
                                    <code>monday|10:00|18:00</code>
                                    or
                                    <code>sunday|closed</code>
                                </p>

<pre>monday|10:00|18:00
tuesday|10:00|18:00
wednesday|10:00|18:00
thursday|10:00|18:00
friday|10:00|18:00
saturday|10:00|16:00
sunday|closed</pre>
                            </td>
                        </tr>
                    </table>

                    <?php submit_button( 'Save Global Business Hours' ); ?>
                </form>
            </div>

            <div class="mobilgo-admin-card">
                <h2>Global Holidays</h2>
                <p class="mobilgo-admin-card-desc">
                    These holidays apply to all locations unless a specific location exception overrides them.
                </p>

                <form method="post" action="options.php">
                    <?php settings_fields( 'mobilgo_system_business_hours_holidays_group' ); ?>

                    <table class="form-table">
                        <tr>
                            <th scope="row">Global Holidays</th>
                            <td>
                                <textarea
                                    name="mobilgo_global_holidays"
                                    rows="10"
                                    class="large-text code"
                                ><?php echo esc_textarea( get_option( 'mobilgo_global_holidays', '' ) ); ?></textarea>

                                <p class="description">
                                    One line per holiday. Format:
                                    <code>YYYY-MM-DD|closed</code>
                                    or
                                    <code>YYYY-MM-DD|10:00|14:00</code>
                                </p>

<pre>2026-12-24|10:00|14:00
2026-12-25|closed
2026-12-26|closed
2026-12-31|10:00|14:00
2027-01-01|closed</pre>
                            </td>
                        </tr>
                    </table>

                    <?php submit_button( 'Save Global Holidays' ); ?>
                </form>
            </div>

            <div class="mobilgo-admin-card">
                <h2>How It Works</h2>
                <p class="mobilgo-admin-card-desc">
                    The system checks business hours and holidays in this order.
                </p>

                <div class="mobilgo-admin-note">
                    1. Location Holiday Exception<br>
                    2. Global Holiday<br>
                    3. Location Business Hours<br>
                    4. Global Business Hours
                </div>
            </div>

        </div>

    </div>
    <?php
}
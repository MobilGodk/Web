<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* =========================
   Add Meta Box
========================= */

function mobilgo_system_location_meta_box() {

    add_meta_box(
        'mobilgo_location_details',
        'Location Details',
        'mobilgo_system_location_meta_callback',
        'mobilgo_location',
        'normal',
        'high'
    );

}
add_action( 'add_meta_boxes', 'mobilgo_system_location_meta_box' );


/* =========================
   Meta Box Layout
========================= */

function mobilgo_system_location_meta_callback( $post ) {

    wp_nonce_field(
        'mobilgo_system_save_location_meta',
        'mobilgo_system_location_nonce'
    );

    $phone_source = get_post_meta( $post->ID, 'mobilgo_phone_source', true );
    $email_source = get_post_meta( $post->ID, 'mobilgo_email_source', true );

    $phone    = get_post_meta( $post->ID, 'mobilgo_phone', true );
    $email    = get_post_meta( $post->ID, 'mobilgo_email', true );
    $address  = get_post_meta( $post->ID, 'mobilgo_address', true );
    $maps_url = get_post_meta( $post->ID, 'mobilgo_maps_url', true );
    $city     = get_post_meta( $post->ID, 'mobilgo_city', true );
    $zip      = get_post_meta( $post->ID, 'mobilgo_zip', true );
    $lat      = get_post_meta( $post->ID, 'mobilgo_lat', true );
    $lng      = get_post_meta( $post->ID, 'mobilgo_lng', true );

    $business_hours = get_post_meta( $post->ID, 'mobilgo_location_business_hours', true );
    $exceptions     = get_post_meta( $post->ID, 'mobilgo_location_holiday_exceptions', true );

    if ( empty( $phone_source ) ) {
        $phone_source = 'main';
    }

    if ( empty( $email_source ) ) {
        $email_source = 'main';
    }

    $iframe_src = '';
    if ( ! empty( $lat ) && ! empty( $lng ) ) {
        $iframe_src = 'https://www.google.com/maps?q=' . rawurlencode( $lat . ',' . $lng ) . '&z=15&output=embed';
    }
?>

<style>
.mobilgo-location-section{
    margin:20px 0;
    padding:18px;
    background:#fff;
    border:1px solid #e5e5e5;
    border-radius:12px;
}
.mobilgo-location-section h2{
    margin:0 0 6px;
    font-size:18px;
}
.mobilgo-location-section p.desc{
    margin:0 0 16px;
    color:#666;
}
.mobilgo-location-field{
    margin-bottom:14px;
}
.mobilgo-location-field label{
    display:block;
    font-weight:600;
    margin-bottom:6px;
}
.mobilgo-location-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:16px;
}
.mobilgo-location-radio-group label{
    display:block;
    margin-bottom:8px;
    font-weight:400;
}
.mobilgo-location-map{
    width:100%;
    height:360px;
    border:1px solid #dcdcde;
    border-radius:8px;
    background:#f6f7f7;
}
.mobilgo-location-help{
    margin-top:8px;
    color:#666;
    font-size:13px;
}
.mobilgo-location-code{
    background:#f6f7f7;
    border:1px solid #e0e0e0;
    border-radius:8px;
    padding:12px;
    font-family:monospace;
    white-space:pre-line;
    color:#333;
}
@media (max-width:782px){
    .mobilgo-location-grid{
        grid-template-columns:1fr;
    }
}
</style>

<div class="mobilgo-location-section">
    <h2>Contact Settings</h2>
    <p class="desc">Choose if this location uses the main business phone/email or custom ones.</p>

    <div class="mobilgo-location-grid">
        <div class="mobilgo-location-field">
            <label>Phone Source</label>
            <div class="mobilgo-location-radio-group">
                <label>
                    <input type="radio" name="mobilgo_phone_source" value="main" <?php checked( $phone_source, 'main' ); ?>>
                    Use Main Phone
                </label>
                <label>
                    <input type="radio" name="mobilgo_phone_source" value="custom" <?php checked( $phone_source, 'custom' ); ?>>
                    Use Custom Phone
                </label>
            </div>
        </div>

        <div class="mobilgo-location-field">
            <label for="mobilgo_phone">Custom Phone</label>
            <input
                type="text"
                id="mobilgo_phone"
                name="mobilgo_phone"
                value="<?php echo esc_attr( $phone ); ?>"
                style="width:100%;"
            >
        </div>

        <div class="mobilgo-location-field">
            <label>Email Source</label>
            <div class="mobilgo-location-radio-group">
                <label>
                    <input type="radio" name="mobilgo_email_source" value="main" <?php checked( $email_source, 'main' ); ?>>
                    Use Main Email
                </label>
                <label>
                    <input type="radio" name="mobilgo_email_source" value="custom" <?php checked( $email_source, 'custom' ); ?>>
                    Use Custom Email
                </label>
            </div>
        </div>

        <div class="mobilgo-location-field">
            <label for="mobilgo_email">Custom Email</label>
            <input
                type="email"
                id="mobilgo_email"
                name="mobilgo_email"
                value="<?php echo esc_attr( $email ); ?>"
                style="width:100%;"
            >
        </div>
    </div>
</div>

<div class="mobilgo-location-section">
    <h2>Address & Map</h2>
    <p class="desc">Search the location with Google Maps and let the system fill the fields automatically.</p>

    <div class="mobilgo-location-field">
        <label for="mobilgo_address">Address Search</label>
        <input
            type="text"
            id="mobilgo_address"
            name="mobilgo_address"
            value="<?php echo esc_attr( $address ); ?>"
            placeholder="Search address with Google..."
            style="width:100%;"
        >
    </div>

    <div class="mobilgo-location-grid">
        <div class="mobilgo-location-field">
            <label for="mobilgo_maps_url">Google Maps URL</label>
            <input
                type="text"
                id="mobilgo_maps_url"
                name="mobilgo_maps_url"
                value="<?php echo esc_attr( $maps_url ); ?>"
                style="width:100%;"
            >
        </div>

        <div class="mobilgo-location-field">
            <label for="mobilgo_city">City</label>
            <input
                type="text"
                id="mobilgo_city"
                name="mobilgo_city"
                value="<?php echo esc_attr( $city ); ?>"
                style="width:100%;"
            >
        </div>

        <div class="mobilgo-location-field">
            <label for="mobilgo_zip">Zip Code</label>
            <input
                type="text"
                id="mobilgo_zip"
                name="mobilgo_zip"
                value="<?php echo esc_attr( $zip ); ?>"
                style="width:100%;"
            >
        </div>

        <div class="mobilgo-location-field">
            <label for="mobilgo_lat">Latitude</label>
            <input
                type="text"
                id="mobilgo_lat"
                name="mobilgo_lat"
                value="<?php echo esc_attr( $lat ); ?>"
                style="width:100%;"
            >
        </div>

        <div class="mobilgo-location-field">
            <label for="mobilgo_lng">Longitude</label>
            <input
                type="text"
                id="mobilgo_lng"
                name="mobilgo_lng"
                value="<?php echo esc_attr( $lng ); ?>"
                style="width:100%;"
            >
        </div>
    </div>

    <div class="mobilgo-location-field">
        <label>Map Preview</label>
        <iframe
            id="mobilgo-location-map-embed"
            class="mobilgo-location-map"
            src="<?php echo esc_url( $iframe_src ); ?>"
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade">
        </iframe>
        <div class="mobilgo-location-help">
            The map preview updates automatically after selecting an address.
        </div>
    </div>
</div>

<div class="mobilgo-location-section">
    <h2>Business Hours (Per Location)</h2>
    <p class="desc">Leave empty to use the global business hours from MobilGo System → Business Hours & Holidays.</p>

    <div class="mobilgo-location-field">
        <label for="mobilgo_location_business_hours">Location Business Hours</label>
        <textarea
            id="mobilgo_location_business_hours"
            name="mobilgo_location_business_hours"
            rows="10"
            style="width:100%;"
        ><?php echo esc_textarea( $business_hours ); ?></textarea>
    </div>

    <div class="mobilgo-location-help">Format examples:</div>
    <div class="mobilgo-location-code">monday|10:00|18:00
tuesday|10:00|18:00
wednesday|10:00|18:00
thursday|10:00|18:00
friday|10:00|18:00
saturday|10:00|16:00
sunday|closed</div>
</div>

<div class="mobilgo-location-section">
    <h2>Holiday Exceptions (Per Location)</h2>
    <p class="desc">These lines override the global holidays for this location only.</p>

    <div class="mobilgo-location-field">
        <label for="mobilgo_location_holiday_exceptions">Location Holiday Exceptions</label>
        <textarea
            id="mobilgo_location_holiday_exceptions"
            name="mobilgo_location_holiday_exceptions"
            rows="8"
            style="width:100%;"
        ><?php echo esc_textarea( $exceptions ); ?></textarea>
    </div>

    <div class="mobilgo-location-help">Format examples:</div>
    <div class="mobilgo-location-code">2026-12-24|10:00|14:00
2026-12-25|closed
2026-12-31|10:00|15:00</div>
</div>

<?php
}


/* =========================
   Save Meta
========================= */

function mobilgo_system_save_location_meta( $post_id ) {

    if ( ! isset( $_POST['mobilgo_system_location_nonce'] ) ) {
        return;
    }

    if ( ! wp_verify_nonce(
        sanitize_text_field( wp_unslash( $_POST['mobilgo_system_location_nonce'] ) ),
        'mobilgo_system_save_location_meta'
    ) ) {
        return;
    }

    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    $text_fields = array(
        'mobilgo_phone_source',
        'mobilgo_email_source',
        'mobilgo_phone',
        'mobilgo_email',
        'mobilgo_address',
        'mobilgo_maps_url',
        'mobilgo_city',
        'mobilgo_zip',
        'mobilgo_lat',
        'mobilgo_lng',
        'mobilgo_location_business_hours',
        'mobilgo_location_holiday_exceptions',
    );

    foreach ( $text_fields as $field ) {
        if ( isset( $_POST[ $field ] ) ) {
            update_post_meta(
                $post_id,
                $field,
                sanitize_textarea_field( wp_unslash( $_POST[ $field ] ) )
            );
        }
    }

}
add_action(
    'save_post_mobilgo_location',
    'mobilgo_system_save_location_meta'
);
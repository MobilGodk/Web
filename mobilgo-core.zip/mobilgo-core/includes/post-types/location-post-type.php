<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* =========================
   Register Location Post Type
========================= */

function mobilgo_system_register_location_post_type() {

    $labels = array(
        'name'                  => __( 'Locations', 'mobilgo-system' ),
        'singular_name'         => __( 'Location', 'mobilgo-system' ),
        'menu_name'             => __( 'Locations', 'mobilgo-system' ),
        'name_admin_bar'        => __( 'Location', 'mobilgo-system' ),
        'add_new'               => __( 'Add New', 'mobilgo-system' ),
        'add_new_item'          => __( 'Add New Location', 'mobilgo-system' ),
        'new_item'              => __( 'New Location', 'mobilgo-system' ),
        'edit_item'             => __( 'Edit Location', 'mobilgo-system' ),
        'view_item'             => __( 'View Location', 'mobilgo-system' ),
        'all_items'             => __( 'All Locations', 'mobilgo-system' ),
        'search_items'          => __( 'Search Locations', 'mobilgo-system' ),
        'not_found'             => __( 'No locations found.', 'mobilgo-system' ),
        'not_found_in_trash'    => __( 'No locations found in Trash.', 'mobilgo-system' ),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => false,
        'show_ui'            => true,
        'show_in_menu'       => 'mobilgo-system-general',
        'menu_icon'          => 'dashicons-location',
        'supports'           => array( 'title' ),
        'has_archive'        => false,
        'rewrite'            => false,
        'query_var'          => false,
        'capability_type'    => 'post',
        'show_in_rest'       => false,
        'exclude_from_search'=> true,
        'publicly_queryable' => false,
    );

    register_post_type( 'mobilgo_location', $args );
}
add_action( 'init', 'mobilgo_system_register_location_post_type' );
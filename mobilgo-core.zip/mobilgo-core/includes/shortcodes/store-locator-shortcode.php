<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* =========================
   Store Locator Shortcode
========================= */

function mobilgo_system_store_locator_shortcode() {

    $locations = mobilgo_system_get_locations();

    ob_start();
    ?>
    <div class="mobilgo-store-locator-wrap">

        <div class="mobilgo-store-locator-toolbar">
            <div class="mobilgo-store-locator-search">
                <input
                    type="text"
                    id="mobilgo-store-search"
                    placeholder="Search by city, area or store name"
                >
            </div>

            <button
                type="button"
                id="mobilgo-use-my-location"
                class="mobilgo-store-toolbar-btn"
            >
                Use My Location
            </button>
        </div>

        <div id="mobilgo-store-locator">

            <div id="mobilgo-store-list">

                <?php if ( ! empty( $locations ) ) : ?>
                    <?php foreach ( $locations as $location ) : ?>

                        <?php
                        $location_id = $location->ID;

                        $title    = get_the_title( $location_id );
                        $address  = mobilgo_system_get_location_address( $location_id );
                        $city     = mobilgo_system_get_location_city( $location_id );
                        $zip      = mobilgo_system_get_location_zip( $location_id );
                        $lat      = mobilgo_system_get_location_lat( $location_id );
                        $lng      = mobilgo_system_get_location_lng( $location_id );
                        $maps_url = mobilgo_system_get_location_maps_url( $location_id );
                        $phone    = mobilgo_system_get_location_phone( $location_id );

                        $phone_clean = preg_replace( '/[^0-9+]/', '', (string) $phone );
                        $is_open     = mobilgo_system_is_location_open_now( $location_id );
                        $today_hours = mobilgo_system_get_today_hours( $location_id );
                        ?>

                        <div
                            class="mobilgo-store-item"
                            data-lat="<?php echo esc_attr( $lat ); ?>"
                            data-lng="<?php echo esc_attr( $lng ); ?>"
                            data-title="<?php echo esc_attr( $title ); ?>"
                            data-address="<?php echo esc_attr( $address ); ?>"
                            data-phone="<?php echo esc_attr( $phone ); ?>"
                            data-phone-link="<?php echo esc_attr( $phone_clean ); ?>"
                            data-maps-url="<?php echo esc_url( $maps_url ); ?>"
                            data-city="<?php echo esc_attr( $city ); ?>"
                            data-zip="<?php echo esc_attr( $zip ); ?>"
                        >

                            <div class="mobilgo-store-card-top">
                                <h3><?php echo esc_html( $title ); ?></h3>

                                <span class="mobilgo-store-badge <?php echo $is_open ? 'is-open' : 'is-closed'; ?>">
                                    <?php echo $is_open ? 'Open Now' : 'Closed'; ?>
                                </span>
                            </div>

                            <?php if ( ! empty( $address ) ) : ?>
                                <p class="mobilgo-store-address">
                                    <?php echo esc_html( $address ); ?>
                                </p>
                            <?php endif; ?>

                            <?php if ( ! empty( $phone ) ) : ?>
                                <p class="mobilgo-store-phone">
                                    <?php echo esc_html( $phone ); ?>
                                </p>
                            <?php endif; ?>

                            <?php if ( ! empty( $today_hours ) ) : ?>
                                <p class="mobilgo-store-hours">
                                    <?php echo esc_html( $today_hours ); ?>
                                </p>
                            <?php endif; ?>

                            <div class="mobilgo-store-meta">
                                <?php if ( ! empty( $city ) ) : ?>
                                    <span><?php echo esc_html( $city ); ?></span>
                                <?php endif; ?>

                                <?php if ( ! empty( $zip ) ) : ?>
                                    <span><?php echo esc_html( $zip ); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="mobilgo-store-distance" aria-live="polite"></div>

                            <div class="mobilgo-store-actions">

                                <?php if ( ! empty( $phone_clean ) ) : ?>
                                    <a
                                        class="mobilgo-store-btn mobilgo-store-btn-call"
                                        href="tel:<?php echo esc_attr( $phone_clean ); ?>"
                                    >
                                        Call
                                    </a>
                                <?php endif; ?>

                                <?php if ( ! empty( $maps_url ) ) : ?>
                                    <a
                                        class="mobilgo-store-btn mobilgo-store-btn-directions"
                                        href="<?php echo esc_url( $maps_url ); ?>"
                                        target="_blank"
                                        rel="noopener"
                                    >
                                        Directions
                                    </a>
                                <?php elseif ( ! empty( $lat ) && ! empty( $lng ) ) : ?>
                                    <a
                                        class="mobilgo-store-btn mobilgo-store-btn-directions"
                                        href="<?php echo esc_url( 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode( $lat . ',' . $lng ) ); ?>"
                                        target="_blank"
                                        rel="noopener"
                                    >
                                        Directions
                                    </a>
                                <?php endif; ?>

                            </div>

                        </div>

                    <?php endforeach; ?>
                <?php else : ?>

                    <div class="mobilgo-store-empty">
                        No locations found.
                    </div>

                <?php endif; ?>

            </div>

            <div class="mobilgo-store-map-col">
                <div id="mobilgo-map"></div>
            </div>

        </div>

    </div>
    <?php
    return ob_get_clean();
}
add_shortcode( 'mobilgo_store_locator', 'mobilgo_system_store_locator_shortcode' );
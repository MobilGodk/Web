<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* =========================
   Default Weekly Hours
   Format:
   monday|10:00|18:00
   sunday|closed
========================= */

function mobilgo_system_parse_weekly_hours( $raw_text ) {

    $lines = preg_split( '/\r\n|\r|\n/', (string) $raw_text );
    $hours = array();

    if ( empty( $lines ) ) {
        return $hours;
    }

    foreach ( $lines as $line ) {

        $line = trim( $line );

        if ( empty( $line ) ) {
            continue;
        }

        $parts = array_map( 'trim', explode( '|', $line ) );

        if ( count( $parts ) === 2 && strtolower( $parts[1] ) === 'closed' ) {

            $hours[ strtolower( $parts[0] ) ] = array(
                'type' => 'closed'
            );

        }

        if ( count( $parts ) === 3 ) {

            $hours[ strtolower( $parts[0] ) ] = array(
                'type'  => 'open',
                'open'  => $parts[1],
                'close' => $parts[2]
            );

        }

    }

    return $hours;

}


/* =========================
   Global Business Hours
========================= */

function mobilgo_system_get_global_hours() {

    $raw = get_option( 'mobilgo_global_business_hours', '' );

    return mobilgo_system_parse_weekly_hours( $raw );

}


/* =========================
   Location Hours
========================= */

function mobilgo_system_get_location_hours( $location_id ) {

    $raw = get_post_meta(
        $location_id,
        'mobilgo_location_business_hours',
        true
    );

    if ( empty( $raw ) ) {
        return mobilgo_system_get_global_hours();
    }

    return mobilgo_system_parse_weekly_hours( $raw );

}


/* =========================
   Get Today Key
========================= */

function mobilgo_system_get_today_key() {

    return strtolower( date( 'l' ) );

}


/* =========================
   Check If Open Now
========================= */

function mobilgo_system_is_location_open_now( $location_id ) {

    $today = mobilgo_system_get_today_key();
    $hours = mobilgo_system_get_location_hours( $location_id );

    if ( empty( $hours[ $today ] ) ) {
        return false;
    }

    $today_hours = $hours[ $today ];

    if ( $today_hours['type'] === 'closed' ) {
        return false;
    }

    $now  = strtotime( current_time( 'H:i' ) );
    $open = strtotime( $today_hours['open'] );
    $close = strtotime( $today_hours['close'] );

    if ( $now >= $open && $now <= $close ) {
        return true;
    }

    return false;

}


/* =========================
   Get Today Hours
========================= */

function mobilgo_system_get_today_hours( $location_id ) {

    $today = mobilgo_system_get_today_key();
    $hours = mobilgo_system_get_location_hours( $location_id );

    if ( empty( $hours[ $today ] ) ) {
        return '';
    }

    $today_hours = $hours[ $today ];

    if ( $today_hours['type'] === 'closed' ) {
        return 'Closed';
    }

    return $today_hours['open'] . ' - ' . $today_hours['close'];

}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* =========================
   Parse Holiday Lines
========================= */

function mobilgo_system_parse_holiday_lines( $raw_text ) {

    $lines = preg_split( '/\r\n|\r|\n/', (string) $raw_text );
    $items = array();

    if ( empty( $lines ) ) {
        return $items;
    }

    foreach ( $lines as $line ) {
        $line = trim( $line );

        if ( empty( $line ) ) {
            continue;
        }

        $parts = array_map( 'trim', explode( '|', $line ) );

        if ( count( $parts ) === 2 && 'closed' === strtolower( $parts[1] ) ) {
            $items[ $parts[0] ] = array(
                'type' => 'closed',
            );
        } elseif ( count( $parts ) === 3 ) {
            $items[ $parts[0] ] = array(
                'type'  => 'custom',
                'open'  => $parts[1],
                'close' => $parts[2],
            );
        }
    }

    return $items;
}


/* =========================
   Global Holidays
========================= */

function mobilgo_system_get_global_holidays() {

    $raw_holidays = get_option( 'mobilgo_global_holidays', '' );

    return mobilgo_system_parse_holiday_lines( $raw_holidays );
}


/* =========================
   Location Holiday Exceptions
========================= */

function mobilgo_system_get_location_holiday_exceptions( $location_id ) {

    $raw_exceptions = get_post_meta(
        $location_id,
        'mobilgo_location_holiday_exceptions',
        true
    );

    return mobilgo_system_parse_holiday_lines( $raw_exceptions );
}


/* =========================
   Holiday Resolver
========================= */

function mobilgo_system_get_holiday_status_for_date( $location_id, $date ) {

    $date = trim( (string) $date );

    if ( empty( $date ) ) {
        return array();
    }

    $location_exceptions = mobilgo_system_get_location_holiday_exceptions( $location_id );
    $global_holidays     = mobilgo_system_get_global_holidays();

    /* Location exception overrides global holiday */
    if ( isset( $location_exceptions[ $date ] ) ) {
        return $location_exceptions[ $date ];
    }

    if ( isset( $global_holidays[ $date ] ) ) {
        return $global_holidays[ $date ];
    }

    return array();
}
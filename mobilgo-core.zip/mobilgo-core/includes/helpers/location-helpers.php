<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* =========================
   Main Business Contact
========================= */

function mobilgo_system_get_main_phone() {
    return (string) get_option( 'mobilgo_main_phone', '' );
}

function mobilgo_system_get_main_email() {
    return (string) get_option( 'mobilgo_main_email', '' );
}

function mobilgo_system_get_business_name() {
    return (string) get_option( 'mobilgo_business_name', '' );
}

function mobilgo_system_get_company_address() {
    return (string) get_option( 'mobilgo_company_address', '' );
}


/* =========================
   Location Contact Logic
========================= */

function mobilgo_system_get_location_phone( $location_id ) {

    $phone_source = get_post_meta( $location_id, 'mobilgo_phone_source', true );
    $custom_phone = get_post_meta( $location_id, 'mobilgo_phone', true );

    if ( 'custom' === $phone_source && ! empty( $custom_phone ) ) {
        return (string) $custom_phone;
    }

    return mobilgo_system_get_main_phone();
}

function mobilgo_system_get_location_email( $location_id ) {

    $email_source = get_post_meta( $location_id, 'mobilgo_email_source', true );
    $custom_email = get_post_meta( $location_id, 'mobilgo_email', true );

    if ( 'custom' === $email_source && ! empty( $custom_email ) ) {
        return (string) $custom_email;
    }

    return mobilgo_system_get_main_email();
}


/* =========================
   Location Data Getters
========================= */

function mobilgo_system_get_location_address( $location_id ) {
    return (string) get_post_meta( $location_id, 'mobilgo_address', true );
}

function mobilgo_system_get_location_city( $location_id ) {
    return (string) get_post_meta( $location_id, 'mobilgo_city', true );
}

function mobilgo_system_get_location_zip( $location_id ) {
    return (string) get_post_meta( $location_id, 'mobilgo_zip', true );
}

function mobilgo_system_get_location_lat( $location_id ) {
    return (string) get_post_meta( $location_id, 'mobilgo_lat', true );
}

function mobilgo_system_get_location_lng( $location_id ) {
    return (string) get_post_meta( $location_id, 'mobilgo_lng', true );
}

function mobilgo_system_get_location_maps_url( $location_id ) {
    return (string) get_post_meta( $location_id, 'mobilgo_maps_url', true );
}


/* =========================
   Location Query Helpers
========================= */

function mobilgo_system_get_locations() {

    return get_posts(
        array(
            'post_type'      => 'mobilgo_location',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'title',
            'order'          => 'ASC',
        )
    );
}

function mobilgo_system_get_location_data( $location_id ) {

    return array(
        'id'       => $location_id,
        'title'    => get_the_title( $location_id ),
        'phone'    => mobilgo_system_get_location_phone( $location_id ),
        'email'    => mobilgo_system_get_location_email( $location_id ),
        'address'  => mobilgo_system_get_location_address( $location_id ),
        'city'     => mobilgo_system_get_location_city( $location_id ),
        'zip'      => mobilgo_system_get_location_zip( $location_id ),
        'lat'      => mobilgo_system_get_location_lat( $location_id ),
        'lng'      => mobilgo_system_get_location_lng( $location_id ),
        'maps_url' => mobilgo_system_get_location_maps_url( $location_id ),
    );
}
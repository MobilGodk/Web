document.addEventListener("DOMContentLoaded", function () {
    if (typeof google === "undefined") {
        return;
    }

    const mapElement = document.getElementById("mobilgo-map");
    const storeItems = Array.from(document.querySelectorAll(".mobilgo-store-item"));
    const searchInput = document.getElementById("mobilgo-store-search");
    const useMyLocationButton = document.getElementById("mobilgo-use-my-location");

    if (!mapElement || !storeItems.length) {
        return;
    }

    const defaultCenter = {
        lat: parseFloat(mobilgoStoreLocator.defaultLat || 55.6761),
        lng: parseFloat(mobilgoStoreLocator.defaultLng || 12.5683)
    };

    const map = new google.maps.Map(mapElement, {
        zoom: parseInt(mobilgoStoreLocator.defaultZoom || 10, 10),
        center: defaultCenter
    });

    const bounds = new google.maps.LatLngBounds();
    const storeData = [];
    let activeInfoWindow = null;

    function buildInfoWindowContent(itemData) {
        let html = '<div style="min-width:220px;">';
        html += '<strong style="display:block;margin-bottom:8px;">' + itemData.title + '</strong>';

        if (itemData.address) {
            html += '<div style="margin-bottom:8px;">' + itemData.address + '</div>';
        }

        if (itemData.phone) {
            html += '<div style="margin-bottom:12px;">' + itemData.phone + '</div>';
        }

        html += '<div style="display:flex;gap:8px;flex-wrap:wrap;">';

        if (itemData.phoneLink) {
            html += '<a href="tel:' + itemData.phoneLink + '" style="background:#111;color:#fff;padding:8px 12px;border-radius:8px;text-decoration:none;font-weight:600;">' + mobilgoStoreLocator.callLabel + '</a>';
        }

        if (itemData.mapsUrl) {
            html += '<a href="' + itemData.mapsUrl + '" target="_blank" rel="noopener" style="background:#d10000;color:#fff;padding:8px 12px;border-radius:8px;text-decoration:none;font-weight:600;">' + mobilgoStoreLocator.directionsLabel + '</a>';
        } else {
            html += '<a href="https://www.google.com/maps/dir/?api=1&destination=' + encodeURIComponent(itemData.lat + ',' + itemData.lng) + '" target="_blank" rel="noopener" style="background:#d10000;color:#fff;padding:8px 12px;border-radius:8px;text-decoration:none;font-weight:600;">' + mobilgoStoreLocator.directionsLabel + '</a>';
        }

        html += '</div></div>';

        return html;
    }

    function setActiveCard(activeItem) {
        storeItems.forEach(function (item) {
            item.classList.remove("is-active");
        });

        if (activeItem) {
            activeItem.classList.add("is-active");
        }
    }

    function focusStore(itemData, openInfoWindow = true) {
        setActiveCard(itemData.element);
        map.setCenter({ lat: itemData.lat, lng: itemData.lng });
        map.setZoom(15);

        if (openInfoWindow) {
            if (activeInfoWindow) {
                activeInfoWindow.close();
            }

            activeInfoWindow = itemData.infoWindow;
            itemData.infoWindow.open(map, itemData.marker);
        }
    }

    function haversineDistance(lat1, lng1, lat2, lng2) {
        const toRad = function (value) {
            return value * Math.PI / 180;
        };

        const earthRadiusKm = 6371;
        const dLat = toRad(lat2 - lat1);
        const dLng = toRad(lng2 - lng1);

        const a =
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
            Math.sin(dLng / 2) * Math.sin(dLng / 2);

        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return earthRadiusKm * c;
    }

    storeItems.forEach(function (item) {
        const lat = parseFloat(item.dataset.lat);
        const lng = parseFloat(item.dataset.lng);

        if (isNaN(lat) || isNaN(lng)) {
            return;
        }

        const itemData = {
            element: item,
            lat: lat,
            lng: lng,
            title: item.dataset.title || "",
            address: item.dataset.address || "",
            phone: item.dataset.phone || "",
            phoneLink: item.dataset.phoneLink || "",
            mapsUrl: item.dataset.mapsUrl || "",
            city: item.dataset.city || "",
            zip: item.dataset.zip || ""
        };

        itemData.infoWindow = new google.maps.InfoWindow({
            content: buildInfoWindowContent(itemData)
        });

        itemData.marker = new google.maps.Marker({
            position: { lat: itemData.lat, lng: itemData.lng },
            map: map,
            title: itemData.title
        });

        itemData.marker.addListener("click", function () {
            focusStore(itemData, true);
        });

        item.addEventListener("click", function () {
            focusStore(itemData, true);
        });

        bounds.extend({ lat: itemData.lat, lng: itemData.lng });
        storeData.push(itemData);
    });

    if (storeData.length) {
        map.fitBounds(bounds);
    }

    if (searchInput) {
        searchInput.addEventListener("input", function () {
            const query = (searchInput.value || "").trim().toLowerCase();

            let visibleCount = 0;
            const visibleBounds = new google.maps.LatLngBounds();

            storeData.forEach(function (store) {
                const haystack = (
                    store.title + " " +
                    store.address + " " +
                    store.city + " " +
                    store.zip + " " +
                    store.phone
                ).toLowerCase();

                const isVisible = !query || haystack.includes(query);

                store.element.style.display = isVisible ? "" : "none";
                store.marker.setVisible(isVisible);

                if (isVisible) {
                    visibleCount++;
                    visibleBounds.extend({ lat: store.lat, lng: store.lng });
                }
            });

            if (visibleCount > 0) {
                map.fitBounds(visibleBounds);
            }
        });
    }

    if (useMyLocationButton) {
        useMyLocationButton.addEventListener("click", function () {
            if (!navigator.geolocation) {
                alert(mobilgoStoreLocator.browserNoGeolocation);
                return;
            }

            useMyLocationButton.disabled = true;
            useMyLocationButton.textContent = mobilgoStoreLocator.locatingLabel;

            navigator.geolocation.getCurrentPosition(
                function (position) {
                    const userLat = position.coords.latitude;
                    const userLng = position.coords.longitude;

                    let nearestStore = null;
                    let nearestDistance = Number.POSITIVE_INFINITY;

                    storeData.forEach(function (store) {
                        const distance = haversineDistance(userLat, userLng, store.lat, store.lng);
                        const distanceWrap = store.element.querySelector(".mobilgo-store-distance");

                        if (distanceWrap) {
                            distanceWrap.textContent = distance.toFixed(1) + " km away";
                        }

                        if (distance < nearestDistance) {
                            nearestDistance = distance;
                            nearestStore = store;
                        }
                    });

                    if (nearestStore) {
                        focusStore(nearestStore, true);

                        const distanceWrap = nearestStore.element.querySelector(".mobilgo-store-distance");
                        if (distanceWrap) {
                            distanceWrap.textContent =
                                mobilgoStoreLocator.nearestStoreLabel + ": " + nearestDistance.toFixed(1) + " km";
                        }

                        nearestStore.element.scrollIntoView({
                            behavior: "smooth",
                            block: "nearest"
                        });
                    }

                    useMyLocationButton.disabled = false;
                    useMyLocationButton.textContent = mobilgoStoreLocator.useMyLocationLabel;
                },
                function () {
                    alert(mobilgoStoreLocator.locationUnavailable);
                    useMyLocationButton.disabled = false;
                    useMyLocationButton.textContent = mobilgoStoreLocator.useMyLocationLabel;
                }
            );
        });
    }
});
document.addEventListener("DOMContentLoaded", function () {
    if (typeof google === "undefined" || !google.maps || !google.maps.places) {
        return;
    }

    const addressInput = document.getElementById("mobilgo_address");
    const latInput = document.getElementById("mobilgo_lat");
    const lngInput = document.getElementById("mobilgo_lng");
    const mapsUrlInput = document.getElementById("mobilgo_maps_url");
    const cityInput = document.getElementById("mobilgo_city");
    const zipInput = document.getElementById("mobilgo_zip");

    if (!addressInput) {
        return;
    }

    const autocomplete = new google.maps.places.Autocomplete(addressInput, {
        fields: ["formatted_address", "geometry", "address_components", "url"]
    });

    autocomplete.addListener("place_changed", function () {
        const place = autocomplete.getPlace();

        if (!place || !place.geometry) {
            return;
        }

        const lat = place.geometry.location.lat();
        const lng = place.geometry.location.lng();

        if (latInput) {
            latInput.value = lat;
        }

        if (lngInput) {
            lngInput.value = lng;
        }

        if (mapsUrlInput && place.url) {
            mapsUrlInput.value = place.url;
        }

        if (addressInput && place.formatted_address) {
            addressInput.value = place.formatted_address;
        }

        if (place.address_components) {
            let city = "";
            let zip = "";

            place.address_components.forEach(function (component) {
                if (
                    component.types.includes("postal_town") ||
                    component.types.includes("locality")
                ) {
                    city = component.long_name;
                }

                if (component.types.includes("postal_code")) {
                    zip = component.long_name;
                }
            });

            if (cityInput) {
                cityInput.value = city;
            }

            if (zipInput) {
                zipInput.value = zip;
            }
        }
    });
});